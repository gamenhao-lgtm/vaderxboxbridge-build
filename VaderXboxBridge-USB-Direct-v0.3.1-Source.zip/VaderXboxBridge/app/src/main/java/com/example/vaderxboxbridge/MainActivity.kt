package com.example.vaderxboxbridge

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbRequest
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.TimeoutException

/** Experimental direct USB XInput reader -> Shizuku shell-UID uinput gamepad. */
class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var connectButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var usbManager: UsbManager
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var remote: IBridgeService? = null
    @Volatile private var binding = false
    @Volatile private var monitorBridgeStatus = false
    @Volatile private var usbRunning = false
    @Volatile private var usbConnection: UsbDeviceConnection? = null
    @Volatile private var usbInterface: UsbInterface? = null
    @Volatile private var usbEndpoint: UsbEndpoint? = null
    @Volatile private var usbRequest: UsbRequest? = null
    @Volatile private var usbReaderThread: Thread? = null
    @Volatile private var usbStartElapsedMs: Long = 0L
    @Volatile private var usbPacketsSeen: Int = 0
    @Volatile private var usbValidReportsSeen: Int = 0
    @Volatile private var lastHandshakeSummary: String = "chưa chạy"
    @Volatile private var firstUsbPacketHex: String = "chưa nhận gói"
    @Volatile private var noUsbDataWarningShown: Boolean = false
    @Volatile private var pendingDirectStart = false
    private var usbReceiverRegistered = false

    private val userServiceArgs: Shizuku.UserServiceArgs
        get() = Shizuku.UserServiceArgs(
            ComponentName(packageName, BridgeUserService::class.java.name)
        ).daemon(true).processNameSuffix("vader_bridge").tag("vader-xbox-bridge").version(3)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IBridgeService.Stub.asInterface(service)
            binding = false
            setStatus("Shizuku đã kết nối. Có thể mở cầu nối USB.")
            setBusy(false)
            if (pendingDirectStart) {
                pendingDirectStart = false
                handler.post { connectUsbController() }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            binding = false
            monitorBridgeStatus = false
            setStatus("Shizuku bị ngắt. Hãy khởi động lại Shizuku rồi kết nối lại.")
            setBusy(false)
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { ensureShizukuPermissionAndBind() }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            remote = null
            binding = false
            monitorBridgeStatus = false
            setStatus("Shizuku đã dừng. Hãy bật lại Shizuku rồi thử kết nối.")
            setBusy(false)
        }
    }
    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_SHIZUKU) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                bindUserService()
            } else {
                pendingDirectStart = false
                runOnUiThread { setStatus("Bạn chưa cấp quyền Shizuku cho app.") }
            }
        }
    }

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            @Suppress("DEPRECATION")
            val device = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
            }
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (device == null) {
                setStatus("Android không trả về thiết bị USB sau khi cấp quyền.")
            } else if (granted) {
                startUsbBridge(device)
            } else {
                setStatus("Bạn chưa cấp quyền USB cho tay cầm.")
            }
        }
    }

    private val statusPoll = object : Runnable {
        override fun run() {
            val svc = remote
            if (usbRunning && usbValidReportsSeen == 0 && !noUsbDataWarningShown &&
                usbStartElapsedMs > 0L && SystemClock.elapsedRealtime() - usbStartElapsedMs > 3500L) {
                noUsbDataWarningShown = true
                val packets = usbPacketsSeen
                if (packets == 0) {
                    setStatus("Đã mở USB nhưng endpoint chưa trả dữ liệu sau handshake=$lastHandshakeSummary. Chưa tạo gamepad ảo.")
                } else {
                    setStatus("Endpoint đã trả $packets gói nhưng chưa có report 00 14. Gói đầu=$firstUsbPacketHex; handshake=$lastHandshakeSummary. Chưa tạo gamepad ảo.")
                }
            }
            if (svc != null && monitorBridgeStatus) {
                io.execute {
                    try {
                        val value = svc.getBridgeStatus()
                        // Keep the USB diagnostic in the foreground while waiting for the first report.
                        if (value.startsWith("ERROR", true) || value.startsWith("Stopped", true) ||
                            value.contains("XInput reports received", true)) {
                            runOnUiThread {
                                setStatus(value)
                                if (value.startsWith("ERROR", true) || value.startsWith("Stopped", true)) {
                                    monitorBridgeStatus = false
                                }
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            setStatus("Lỗi giao tiếp với Shizuku: ${e.message}")
                            monitorBridgeStatus = false
                        }
                    }
                }
            }
            handler.postDelayed(this, 900L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        registerUsbPermissionReceiver()
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        setStatus("Cắm Vader 5 Pro bằng USB OTG, rồi kết nối Shizuku.")
        if (Shizuku.pingBinder()) ensureShizukuPermissionAndBind()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(statusPoll)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        usbRunning = false
        try { usbRequest?.cancel() } catch (_: Exception) { }
        try { usbConnection?.close() } catch (_: Exception) { }
        try { remote?.stopBridge() } catch (_: Exception) { }
        if (usbReceiverRegistered) {
            try { unregisterReceiver(usbPermissionReceiver) } catch (_: Exception) { }
            usbReceiverRegistered = false
        }
        try { Shizuku.unbindUserService(userServiceArgs, serviceConnection, false) } catch (_: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val outer = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }
        outer.addView(root)

        root.addView(TextView(this).apply {
            text = "Vader Xbox Bridge"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, lp())

        root.addView(TextView(this).apply {
            text = "USB trực tiếp: Flydigi Vader 5 Pro → XInput → Xbox 360 ảo"
            textSize = 14f
        }, lp(top = 5))

        root.addView(TextView(this).apply {
            text = "Bản thử nghiệm có chẩn đoán tách riêng USB và gamepad ảo. Chỉ tạo gamepad ảo sau khi nhận report XInput hợp lệ. Android/firmware vẫn có thể chặn /dev/uinput hoặc game có thể không nhận gamepad ảo."
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFF1CC.toInt())
        }, lp(top = 14))

        connectButton = Button(this).apply {
            text = "1. Kết nối Shizuku"
            setOnClickListener { ensureShizukuPermissionAndBind() }
        }
        root.addView(connectButton, lp(top = 14))

        startButton = Button(this).apply {
            text = "2. Bắt đầu cầu nối USB → Xbox"
            setOnClickListener { connectUsbController() }
        }
        root.addView(startButton, lp(top = 6))

        stopButton = Button(this).apply {
            text = "Dừng cầu nối"
            setOnClickListener { stopBridge() }
        }
        root.addView(stopButton, lp(top = 6))

        statusView = TextView(this).apply {
            text = "Trạng thái: Chưa kết nối"
            textSize = 14f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEFEFEF.toInt())
        }
        root.addView(statusView, lp(top = 14))

        root.addView(TextView(this).apply {
            text = "App tìm USB VID/PID 37D7:2401; gửi đủ 3 control-IN handshake của XInput có dây; đợi report 00 14; sau đó mới tạo gamepad ảo. Nút chính, D-pad, cò và hai cần analog được chuyển tiếp. Gyro/M1–M4 chưa được triển khai."
            textSize = 13f
        }, lp(top = 12))

        setContentView(outer)
        setBusy(false)
    }

    private fun registerUsbPermissionReceiver() {
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbPermissionReceiver, filter)
        }
        usbReceiverRegistered = true
    }

    private fun ensureShizukuPermissionAndBind() {
        if (remote != null) {
            setStatus("Shizuku đã kết nối. Có thể mở cầu nối USB.")
            return
        }
        if (binding) {
            setStatus("Đang kết nối Shizuku…")
            return
        }
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku chưa chạy. Hãy mở Shizuku, khởi động bằng Wireless debugging rồi quay lại app.")
            setBusy(false)
            return
        }
        try {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Đang chờ bạn cấp quyền Shizuku…")
                Shizuku.requestPermission(REQUEST_SHIZUKU)
            } else {
                bindUserService()
            }
        } catch (e: Exception) {
            setStatus("Không kiểm tra được Shizuku: ${e.message}")
        }
    }

    private fun bindUserService() {
        if (remote != null || binding) return
        binding = true
        setBusy(true)
        setStatus("Đang mở dịch vụ cầu nối với UID shell…")
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Exception) {
            binding = false
            setBusy(false)
            setStatus("Không khởi động được dịch vụ Shizuku: ${e.message}")
        }
    }

    private fun connectUsbController() {
        if (usbRunning) {
            setStatus("Cầu nối USB đã chạy. Bấm Dừng trước khi kết nối lại.")
            return
        }
        if (remote == null) {
            pendingDirectStart = true
            ensureShizukuPermissionAndBind()
            return
        }
        val device = usbManager.deviceList.values.firstOrNull {
            it.vendorId == VADER_VENDOR_ID && it.productId == VADER_PRODUCT_ID
        }
        if (device == null) {
            setStatus("Không thấy USB 37D7:2401. Kiểm tra cáp OTG, đầu chuyển và chế độ kết nối có dây của tay cầm.")
            return
        }
        if (!usbManager.hasPermission(device)) {
            val intent = Intent(ACTION_USB_PERMISSION).setPackage(packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val permissionIntent = PendingIntent.getBroadcast(this, USB_PERMISSION_REQUEST, intent, flags)
            setStatus("Đang chờ Android cấp quyền USB cho Vader 5 Pro…")
            usbManager.requestPermission(device, permissionIntent)
            return
        }
        startUsbBridge(device)
    }

    private fun startUsbBridge(device: UsbDevice) {
        val svc = remote
        if (svc == null) {
            setStatus("Shizuku chưa kết nối. Bấm Kết nối Shizuku trước.")
            return
        }
        setBusy(true)
        monitorBridgeStatus = false
        setStatus("Đang mở USB interface XInput…")
        io.execute {
            var connectionForCleanup: UsbDeviceConnection? = null
            var interfaceForCleanup: UsbInterface? = null
            var requestForCleanup: UsbRequest? = null
            try {
                val usbInterface = (0 until device.interfaceCount)
                    .map { device.getInterface(it) }
                    .firstOrNull {
                        it.interfaceClass == 0xFF && it.interfaceSubclass == 0x5D && it.interfaceProtocol == 0x01
                    } ?: throw IOException("Không tìm thấy interface XInput FF/5D/01 trên tay cầm.")

                val endpoint = (0 until usbInterface.endpointCount)
                    .map { usbInterface.getEndpoint(it) }
                    .firstOrNull {
                        it.address == 0x81 && it.direction == UsbConstants.USB_DIR_IN &&
                            it.type == UsbConstants.USB_ENDPOINT_XFER_INT
                    } ?: (0 until usbInterface.endpointCount).map { usbInterface.getEndpoint(it) }
                    .firstOrNull {
                        it.direction == UsbConstants.USB_DIR_IN && it.type == UsbConstants.USB_ENDPOINT_XFER_INT
                    } ?: throw IOException("Không tìm thấy endpoint interrupt IN của XInput.")

                val opened = usbManager.openDevice(device)
                    ?: throw IOException("Android không mở được thiết bị USB; có thể quyền USB bị từ chối.")
                connectionForCleanup = opened
                if (!opened.claimInterface(usbInterface, true)) {
                    throw IOException("Không chiếm được interface XInput; có thể driver hệ thống đang giữ interface.")
                }
                interfaceForCleanup = usbInterface

                // The wired Vader 5 Pro does not stream until all three Xbox 360 start
                // control-IN requests have been issued (matching the observed xpad sequence).
                val handshakeResults = arrayListOf<Int>()
                val handshakeRequests = arrayOf(
                    intArrayOf(0xC1, 0x01, 0x0100),
                    intArrayOf(0xC1, 0x01, 0x0000),
                    intArrayOf(0xC0, 0x01, 0x0000)
                )
                for (setup in handshakeRequests) {
                    val data = ByteArray(20)
                    val result = opened.controlTransfer(
                        setup[0], setup[1], setup[2], usbInterface.id, data, data.size, 1000
                    )
                    handshakeResults.add(result)
                }
                val handshakeSummary = handshakeResults.joinToString(prefix = "[", postfix = "]")
                lastHandshakeSummary = handshakeSummary
                val request = UsbRequest()
                if (!request.initialize(opened, endpoint)) {
                    throw IOException("Không khởi tạo được UsbRequest cho endpoint 0x${endpoint.address.toString(16)}.")
                }
                requestForCleanup = request

                // Do not create /dev/uinput yet. First prove that USB actually returns a valid
                // 00 14 XInput report; this separates USB/handshake failures from uinput denial.
                usbConnection = opened
                this.usbInterface = usbInterface
                usbEndpoint = endpoint
                usbRequest = request
                usbPacketsSeen = 0
                usbValidReportsSeen = 0
                firstUsbPacketHex = "chưa nhận gói"
                noUsbDataWarningShown = false
                usbStartElapsedMs = SystemClock.elapsedRealtime()
                usbRunning = true
                monitorBridgeStatus = true

                val reader = Thread({ readUsbReports(opened, usbInterface, endpoint, request, svc) }, "Vader5ProUsbReader")
                reader.isDaemon = true
                usbReaderThread = reader
                // Queue this waiting state before the reader can enqueue its success state.
                handler.post {
                    setStatus("USB interface XInput đã mở; handshake results=$handshakeSummary. Đang đợi report 00 14 trước khi tạo gamepad ảo.")
                    setBusy(false)
                }
                reader.start()
            } catch (e: Exception) {
                usbRunning = false
                try { requestForCleanup?.close() } catch (_: Exception) { }
                try {
                    if (connectionForCleanup != null && interfaceForCleanup != null) {
                        connectionForCleanup.releaseInterface(interfaceForCleanup)
                    }
                } catch (_: Exception) { }
                try { connectionForCleanup?.close() } catch (_: Exception) { }
                if (usbConnection === connectionForCleanup) usbConnection = null
                if (this.usbInterface === interfaceForCleanup) this.usbInterface = null
                usbEndpoint = null
                usbRequest = null
                handler.post {
                    monitorBridgeStatus = false
                    setStatus("USB bridge failed: ${e.message ?: e.javaClass.simpleName}")
                    setBusy(false)
                }
            }
        }
    }

    private fun readUsbReports(
        connection: UsbDeviceConnection,
        usbInterface: UsbInterface,
        endpoint: UsbEndpoint,
        request: UsbRequest,
        svc: IBridgeService
    ) {
        val buffer = ByteBuffer.allocateDirect(maxOf(endpoint.maxPacketSize, 32))
        var lastSentState: ByteArray? = null
        var validReportsSeen = 0
        var failureMessage: String? = null
        var requestQueued = false
        var virtualStarted = false
        try {
            while (usbRunning) {
                if (!requestQueued) {
                    buffer.clear()
                    if (!request.queue(buffer)) throw IOException("USB request queue() failed.")
                    requestQueued = true
                }
                // Timeout is only for status diagnostics. The queued request remains outstanding
                // after a timeout, so do not queue the same UsbRequest a second time.
                // Android's timed requestWait throws TimeoutException when no interrupt
                // packet arrives before the deadline. A timeout is expected while the
                // controller is idle; the request remains queued, so keep waiting without
                // queueing the same UsbRequest again.
                val completed = try {
                    connection.requestWait(750L)
                } catch (_: TimeoutException) {
                    continue
                }
                if (!usbRunning) break
                if (completed == null) throw IOException("USB requestWait returned null (USB request error).")
                if (completed !== request) throw IOException("USB returned an unexpected completed request.")
                requestQueued = false
                buffer.flip()
                val length = buffer.remaining()
                if (length <= 0) continue
                val report = ByteArray(length)
                buffer.get(report)
                usbPacketsSeen++
                if (usbPacketsSeen == 1) {
                    firstUsbPacketHex = report.take(16).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
                }

                val standardXInput = report.size >= 14 &&
                    (report[0].toInt() and 0xFF) == 0x00 &&
                    (report[1].toInt() and 0xFF) == 0x14
                if (standardXInput) {
                    validReportsSeen++
                    usbValidReportsSeen = validReportsSeen
                    if (!virtualStarted) {
                        if (!svc.startXboxReportBridge()) {
                            throw IOException("USB XInput report arrived, but virtual gamepad creation failed: ${svc.getBridgeStatus()}")
                        }
                        virtualStarted = true
                    }
                    // Ignore the tail (counter/reserved bytes) when comparing state to avoid
                    // unnecessary Binder calls when only packet metadata changes.
                    val state = report.copyOfRange(0, 14)
                    val previous = lastSentState
                    if (previous == null || !state.contentEquals(previous)) {
                        svc.sendXboxReport(report)
                        lastSentState = state
                    }
                    if (validReportsSeen == 1) {
                        handler.post { setStatus("Đã nhận report XInput 00 14 và tạo gamepad ảo; đang chuyển nút, cò và analog.") }
                    }
                } else if (usbPacketsSeen == 50) {
                    val hex = report.take(12).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
                    handler.post { setStatus("USB có dữ liệu nhưng report không phải XInput 00 14. Mẫu đầu: $hex. Handshake=$lastHandshakeSummary") }
                }
            }
        } catch (e: Exception) {
            if (usbRunning) failureMessage = e.message ?: e.javaClass.simpleName
        } finally {
            val endedUnexpectedly = usbRunning
            usbRunning = false
            monitorBridgeStatus = false
            try { request.cancel() } catch (_: Exception) { }
            try { request.close() } catch (_: Exception) { }
            try { connection.releaseInterface(usbInterface) } catch (_: Exception) { }
            try { connection.close() } catch (_: Exception) { }
            if (usbConnection === connection) usbConnection = null
            if (this.usbInterface === usbInterface) this.usbInterface = null
            usbEndpoint = null
            usbRequest = null
            usbReaderThread = null

            if (endedUnexpectedly) {
                try { if (virtualStarted) svc.stopBridge() } catch (_: Exception) { }
                handler.post {
                    setStatus("USB bridge dừng ngoài ý muốn: ${failureMessage ?: "thiết bị đã ngắt kết nối"}")
                    setBusy(false)
                }
            }
        }
    }

    private fun stopBridge() {
        usbRunning = false
        monitorBridgeStatus = false
        usbStartElapsedMs = 0L
        try { usbRequest?.cancel() } catch (_: Exception) { }
        try { usbConnection?.close() } catch (_: Exception) { }
        val svc = remote
        if (svc == null) {
            setStatus("Shizuku chưa kết nối.")
            setBusy(false)
            return
        }
        setBusy(true)
        monitorBridgeStatus = false
        io.execute {
            try {
                svc.stopBridge()
                val value = svc.getBridgeStatus()
                handler.post {
                    setStatus(value)
                    setBusy(false)
                }
            } catch (e: Exception) {
                handler.post {
                    setStatus("Dừng cầu nối thất bại: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun setStatus(text: String) {
        if (::statusView.isInitialized) statusView.text = "Trạng thái: $text"
    }

    private fun setBusy(busy: Boolean) {
        if (::connectButton.isInitialized) {
            connectButton.isEnabled = !busy
            startButton.isEnabled = !busy
            stopButton.isEnabled = !busy
        }
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { if (top > 0) topMargin = dp(top) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private const val REQUEST_SHIZUKU = 2407
        private const val USB_PERMISSION_REQUEST = 2408
        private const val ACTION_USB_PERMISSION = "com.example.vaderxboxbridge.USB_PERMISSION"
        private const val VADER_VENDOR_ID = 0x37D7
        private const val VADER_PRODUCT_ID = 0x2401
    }
}
