# Vader Xbox Bridge 0.1 — prototype source project

Vietnamese instructions: see [README_VI.md](README_VI.md).

This is an experimental Android Studio project intended to bridge standard Linux gamepad events from a physical USB-OTG controller to a system-wide virtual Xbox 360 input device via Shizuku and `/dev/uinput`.

**This is source code, not a prebuilt APK. It has not been built with the Android SDK or tested on a real Xiaomi Pad 6 / Flydigi Vader 5 Pro.** The native C++ file passed a host-side syntax check, and the Java UserService file passed a basic Java syntax check with stubs; those checks do not establish that the Android project compiles or works on-device.

Main limitations: only common Linux gamepad buttons/axes are forwarded; gyro and full Flydigi-specific M1–M4 semantics are not implemented. Rootless access to `/dev/input/event*`, `EVIOCGRAB` and `/dev/uinput` depends on the device firmware and SELinux policy.
