package com.example.vaderxboxbridge

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/** Experimental evdev -> uinput bridge. Not yet tested on the user's physical tablet/controller. */
class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var scanButton: Button
    private lateinit var connectButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<DeviceEntry>()
    @Volatile private var remote: IBridgeService? = null
    @Volatile private var binding = false

    private val userServiceArgs: Shizuku.UserServiceArgs
        get() = Shizuku.UserServiceArgs(
            ComponentName(packageName, BridgeUserService::class.java.name)
        ).daemon(true).processNameSuffix("vader_bridge").tag("vader-xbox-bridge").version(1)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IBridgeService.Stub.asInterface(service)
            binding = false
            setStatus("Shizuku connected. Scan for the physical controller.")
            setBusy(false)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            binding = false
            setStatus("Shizuku bridge disconnected. Check that Shizuku is still running.")
            setBusy(false)
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { ensureShizukuPermissionAndBind() }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            remote = null
            binding = false
            setStatus("Shizuku stopped. Start it again, then reconnect here.")
            setBusy(false)
        }
    }
    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_SHIZUKU) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                bindUserService()
            } else {
                runOnUiThread { setStatus("Shizuku permission was denied.") }
            }
        }
    }

    private val statusPoll = object : Runnable {
        override fun run() {
            val svc = remote
            if (svc != null) {
                io.execute {
                    try {
                        val value = svc.getBridgeStatus()
                        runOnUiThread { statusView.text = "Status: $value" }
                    } catch (e: Exception) {
                        runOnUiThread { statusView.text = "Status: service communication error — ${e.message}" }
                    }
                }
            }
            handler.postDelayed(this, 900L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        setStatus("Experimental prototype. Connect Vader 5 Pro by USB OTG, then connect Shizuku.")
        if (Shizuku.pingBinder()) ensureShizukuPermissionAndBind()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        if (binding) {
            try { Shizuku.unbindUserService(userServiceArgs, serviceConnection, false) } catch (_: Exception) { }
        } else {
            try { Shizuku.unbindUserService(userServiceArgs, serviceConnection, false) } catch (_: Exception) { }
        }
        io.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val outer = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }
        outer.addView(root)

        val title = TextView(this).apply {
            text = "Vader Xbox Bridge"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Prototype: physical USB controller → system-wide virtual Xbox 360 controller"
            textSize = 14f
        }
        root.addView(subtitle, lp(top = 4))

        val warning = TextView(this).apply {
            text = "Not an APK from a verified release. This source prototype must be built and tested; no guarantee it works on Xiaomi Pad 6 or COD Mobile."
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFF1CC.toInt())
        }
        root.addView(warning, lp(top = 14))

        connectButton = Button(this).apply {
            text = "1. Connect Shizuku"
            setOnClickListener { ensureShizukuPermissionAndBind() }
        }
        root.addView(connectButton, lp(top = 14))

        scanButton = Button(this).apply {
            text = "2. Scan physical gamepads"
            setOnClickListener { scanDevices() }
        }
        root.addView(scanButton, lp(top = 6))

        devicesSpinner = Spinner(this)
        root.addView(devicesSpinner, lp(top = 6))

        startButton = Button(this).apply {
            text = "3. Start Xbox bridge"
            setOnClickListener { startBridge() }
        }
        root.addView(startButton, lp(top = 6))

        stopButton = Button(this).apply {
            text = "Stop bridge"
            setOnClickListener { stopBridge() }
        }
        root.addView(stopButton, lp(top = 6))

        statusView = TextView(this).apply {
            text = "Status: Idle"
            textSize = 14f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEFEFEF.toInt())
        }
        root.addView(statusView, lp(top = 14))

        val note = TextView(this).apply {
            text = "What this prototype attempts: Shizuku shell reads Linux /dev/input/event* and creates a virtual Xbox gamepad via /dev/uinput. If Android blocks either operation, it will report the error. Gyro and Flydigi-specific M1–M4 mapping are not implemented yet."
            textSize = 13f
        }
        root.addView(note, lp(top = 12))
        setContentView(outer)
        setBusy(false)
    }

    private fun ensureShizukuPermissionAndBind() {
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku is not running. Open Shizuku and start it with Wireless debugging, then return here.")
            setBusy(false)
            return
        }
        try {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Waiting for Shizuku permission…")
                Shizuku.requestPermission(REQUEST_SHIZUKU)
            } else {
                bindUserService()
            }
        } catch (e: Exception) {
            setStatus("Shizuku check failed: ${e.message}")
        }
    }

    private fun bindUserService() {
        if (remote != null || binding) return
        binding = true
        setBusy(true)
        setStatus("Binding shell-UID bridge service…")
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Exception) {
            binding = false
            setBusy(false)
            setStatus("Could not start Shizuku service: ${e.message}")
        }
    }

    private fun scanDevices() {
        val svc = remote
        if (svc == null) {
            ensureShizukuPermissionAndBind()
            setStatus("Connect Shizuku first, then scan again.")
            return
        }
        setBusy(true)
        setStatus("Scanning /dev/input/event* via getevent…")
        io.execute {
            try {
                val result = svc.listDevices() ?: emptyArray()
                runOnUiThread {
                    entries.clear()
                    val error = result.firstOrNull { it.startsWith("__ERROR__\t") }
                    if (error != null) {
                        setStatus(error.substringAfter('\t'))
                        setDevices(emptyList())
                    } else {
                        for (item in result) {
                            val parts = item.split('\t', limit = 2)
                            if (parts.size == 2) {
                                val paths = parts[1].split(';').filter { it.startsWith("/dev/input/event") }
                                if (paths.isNotEmpty()) entries.add(DeviceEntry(parts[0], paths))
                            }
                        }
                        setDevices(entries)
                        if (entries.isEmpty()) {
                            setStatus("No gamepad-like event node found. Check USB OTG/controller mode, then scan again.")
                        } else {
                            val flydigiIndex = entries.indexOfFirst { it.name.contains("flydigi", true) || it.name.contains("vader", true) }
                            if (flydigiIndex >= 0) devicesSpinner.setSelection(flydigiIndex)
                            setStatus("Found ${entries.size} gamepad candidate(s). Select Flydigi Vader 5 Pro if listed.")
                        }
                    }
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("Scan failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun startBridge() {
        val svc = remote
        if (svc == null) {
            ensureShizukuPermissionAndBind()
            setStatus("Connect Shizuku first.")
            return
        }
        val entry = entries.getOrNull(devicesSpinner.selectedItemPosition)
        if (entry == null) {
            setStatus("Scan and select the Flydigi controller first.")
            return
        }
        setBusy(true)
        setStatus("Starting bridge for ${entry.name}…")
        io.execute {
            try {
                val started = svc.startBridge(entry.paths.toTypedArray(), entry.name)
                runOnUiThread {
                    setStatus(if (started) "Start requested. Watch the status below for RUNNING or an explicit error." else svc.getBridgeStatus())
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("Start failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun stopBridge() {
        val svc = remote
        if (svc == null) {
            setStatus("Bridge service is not connected.")
            return
        }
        setBusy(true)
        io.execute {
            try {
                svc.stopBridge()
                val text = svc.getBridgeStatus()
                runOnUiThread {
                    setStatus(text)
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("Stop failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun setDevices(list: List<DeviceEntry>) {
        val labels = if (list.isEmpty()) listOf("No gamepad detected") else list.map {
            "${it.name}  •  ${it.paths.joinToString()}"
        }
        devicesSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun setStatus(text: String) {
        if (::statusView.isInitialized) statusView.text = "Status: $text"
    }

    private fun setBusy(busy: Boolean) {
        if (::scanButton.isInitialized) {
            scanButton.isEnabled = !busy
            connectButton.isEnabled = !busy
            startButton.isEnabled = !busy
            stopButton.isEnabled = !busy
        }
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { if (top > 0) topMargin = dp(top) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private data class DeviceEntry(val name: String, val paths: List<String>)

    companion object {
        private const val REQUEST_SHIZUKU = 2407
    }
}
