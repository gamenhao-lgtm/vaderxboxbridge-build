# Vader Xbox Bridge 0.1.1 — bản sửa chẩn đoán (mã nguồn)

## Mục tiêu

Tạo cầu nối trên cùng thiết bị Android:

`Flydigi Vader 5 Pro USB OTG → Linux evdev (/dev/input/event*) → Xbox 360 ảo (/dev/uinput) → game`

Ứng dụng dùng Shizuku để chạy bộ đọc sự kiện và tạo thiết bị ảo với UID `shell` (không root). Nó không dùng mapping cảm ứng.

## Quan trọng — chưa phải APK đã xác minh

Đây là **mã nguồn đã sửa nhưng chưa phải APK**. Bản vá sửa lỗi trạng thái `Idle/Stopped` cũ ghi đè thông báo mới, gom capability từ nhiều event node cùng tên trước khi nhận diện tay cầm, và hiện chẩn đoán danh sách node mà Shizuku nhìn thấy nếu bộ lọc không nhận diện được. Môi trường tạo tệp hiện tại không có Android SDK/NDK, vì vậy chưa thể xác nhận toàn bộ dự án Android biên dịch thành công hoặc hoạt động trên thiết bị thật.

Có ba điều kiện cần đúng trên Xiaomi Pad 6:

1. `getevent -lp` phải liệt kê được node của Vader 5 Pro.
2. Shizuku shell phải được đọc `/dev/input/event*` và dùng `EVIOCGRAB`.
3. Firmware phải cho shell mở `/dev/uinput` và tạo Xbox 360 ảo.

Nếu một điều kiện bị hệ thống chặn, app sẽ báo lỗi cụ thể thay vì giả vờ đã kết nối. Không root, không chỉnh SELinux.

## Những gì prototype có

- Quét node input Linux, gom các node cùng tên trước khi nhận diện để hỗ trợ trường hợp nút và analog bị Android tách riêng; nếu không thấy ứng viên, hiển thị một số tên node và loại capability để chẩn đoán.
- Tạo thiết bị ảo tên `Microsoft X-Box 360 pad` với VID/PID kiểu Xbox 360.
- Chuyển các nút Linux gamepad phổ biến và các trục analog X/Y, RX/RY, Z/RZ, HAT0X/HAT0Y.
- Có Start/Stop và trạng thái lỗi; khi chạy thì grab input vật lý để tránh gửi trùng, khi dừng sẽ nhả grab và hủy thiết bị ảo.

Chưa có gyro, rung, calibration UI hay mapping riêng M1–M4. Nếu M1–M4 được hệ thống xuất ra dưới dạng `BTN_TRIGGER_HAPPY`, prototype sẽ chuyển mã đó, nhưng game không nhất thiết gán chúng thành nút chức năng.

## Build trên Windows

### Cần cài

- Android Studio bản mới (JDK 17 trở lên).
- Android SDK Platform 35.
- Android NDK `27.0.12077973`.
- CMake `3.22.1`.
- Shizuku trên tablet, khởi động bằng Wireless debugging (không root).

Trong Android Studio, mở `VaderXboxBridge` rồi đợi Gradle Sync. Nếu Android Studio báo thiếu SDK/NDK/CMake, mở **Tools → SDK Manager → SDK Tools** và cài các mục ở trên.

Có thể chạy `build-apk.bat` từ Windows sau khi cài xong Android SDK/NDK/CMake. Script tải Gradle 8.10.2 từ máy chủ chính thức của Gradle và chạy `assembleDebug`. APK, nếu build thành công, sẽ nằm ở:

`app\build\outputs\apk\debug\app-debug.apk`

## Cách thử an toàn

1. Cài APK do chính bạn build; mở Shizuku và xác nhận trạng thái Running.
2. Thoát/ngắt Kishi Controller Bridge và dừng chế độ Local của GKME trước khi thử để tránh nhiều thiết bị ảo cùng lúc.
3. Cắm Vader 5 Pro qua USB OTG, mở Vader Xbox Bridge, bấm **Connect Shizuku**.
4. Bấm **Scan physical gamepads** và chọn mục có tên Flydigi/Vader.
5. Bấm **Start Xbox bridge**. Chỉ tiếp tục nếu trạng thái hiện `RUNNING`.
6. Mở app test tay cầm. Tên Xbox ảo phải phản ánh nút và trục analog khi bấm/gạt tay cầm thật.
7. Để dừng, quay lại app và bấm **Stop bridge**.

Nếu báo `Permission denied` với `/dev/input/event...`, `EVIOCGRAB` hoặc `/dev/uinput`, đừng root máy chỉ để thử prototype này. Gửi nguyên dòng lỗi để xác định giới hạn firmware.

## Lưu ý về game

Thiết bị ảo chỉ chuẩn hóa đầu vào; nó không bảo đảm mọi game sẽ chấp nhận thiết bị ảo hoặc hỗ trợ tay cầm. Hãy tuân thủ quy định của game. Không có tính năng tự động hóa thao tác, macro, aim assist hay tiêm thao tác cảm ứng.


## Những gì đã sửa trong bản 0.1.1

- Không còn để trạng thái `Idle` / `Stopped` cũ liên tục ghi đè trạng thái kết nối hoặc kết quả quét.
- Khi nhấn Connect nhưng Shizuku chưa kết nối, giữ lại thông báo lỗi/kết nối thay vì thay ngay bằng một thông báo chung.
- Nếu `getevent` thấy thiết bị nhưng bộ lọc không xác định được tay cầm, hiển thị tên và đường dẫn của một số node đầu vào để xác định vấn đề.
- Đây vẫn là bản thử nghiệm: nếu firmware chặn quyền đọc `/dev/input/event*`, `EVIOCGRAB` hoặc tạo `/dev/uinput`, sửa mã không thể tự vượt qua hạn chế hệ thống.
