package com.example.vaderxboxbridge;

interface IBridgeService {
    String[] listDevices();
    boolean startBridge(in String[] paths, String name);
    void stopBridge();
    String getBridgeStatus();
}
