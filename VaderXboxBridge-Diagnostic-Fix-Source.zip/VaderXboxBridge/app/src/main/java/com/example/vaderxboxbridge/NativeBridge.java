package com.example.vaderxboxbridge;

/** Native event reader and Linux uinput writer, loaded inside Shizuku's shell-UID UserService. */
public final class NativeBridge {
    static {
        System.loadLibrary("vaderbridge");
    }

    private NativeBridge() { }

    /** Blocks until stop is requested or an input/output error occurs. */
    public static native void runBridge(String[] eventPaths, String physicalName);
    public static native void stopBridge();
    public static native String getBridgeStatus();
}
