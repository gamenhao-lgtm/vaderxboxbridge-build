package com.example.vaderxboxbridge;

import android.os.RemoteException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Runs as Shizuku's shell UID, allowing it to inspect evdev and create a uinput gamepad. */
public final class BridgeUserService extends IBridgeService.Stub {
    private volatile Thread bridgeThread;
    private volatile String localStatus = "Idle";

    private static final Pattern DEVICE_HEADER = Pattern.compile("^add device \\d+: (.+)$");
    private static final Pattern DEVICE_NAME = Pattern.compile("^\\s*name: \"(.*)\"\\s*$");

    public BridgeUserService() {
        super();
    }

    @Override
    public String[] listDevices() throws RemoteException {
        Process process = null;
        try {
            process = new ProcessBuilder("/system/bin/getevent", "-lp")
                    .redirectErrorStream(true)
                    .start();
            List<DeviceBlock> blocks = new ArrayList<>();
            DeviceBlock current = null;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    Matcher header = DEVICE_HEADER.matcher(line.trim());
                    if (header.matches()) {
                        if (current != null) blocks.add(current);
                        current = new DeviceBlock();
                        current.path = header.group(1).trim();
                        continue;
                    }
                    if (current == null) continue;
                    Matcher nameMatcher = DEVICE_NAME.matcher(line);
                    if (nameMatcher.matches()) current.name = nameMatcher.group(1);
                    current.capabilities.append(line).append('\n');
                }
            }
            if (current != null) blocks.add(current);
            if (!process.waitFor(4, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return new String[]{"__ERROR__\tgetevent timed out"};
            }
            if (process.exitValue() != 0) {
                return new String[]{"__ERROR__\tgetevent failed with exit code " + process.exitValue()};
            }

            // Merge capabilities by physical device name BEFORE applying the gamepad filter.
            // Android may expose buttons and axes as separate event nodes for the same controller.
            Map<String, DeviceBlock> groups = new LinkedHashMap<>();
            for (DeviceBlock block : blocks) {
                if (block.name == null || block.path == null || !block.path.startsWith("/dev/input/event")) continue;
                DeviceBlock merged = groups.computeIfAbsent(block.name, key -> new DeviceBlock());
                merged.name = block.name;
                if (!merged.paths.contains(block.path)) merged.paths.add(block.path);
                merged.capabilities.append(block.capabilities).append('\n');
            }

            List<String> result = new ArrayList<>();
            List<String> visibleNodes = new ArrayList<>();
            for (DeviceBlock block : groups.values()) {
                String caps = block.capabilities.toString();
                String pathList = String.join(";", block.paths);
                if (looksLikeGamepad(block)) {
                    // The tab separates the display name from the semicolon-separated event paths.
                    result.add(block.name + "\t" + pathList);
                }
                if (visibleNodes.size() < 8) {
                    String markers = capabilitySummary(caps);
                    visibleNodes.add(block.name + " (" + pathList + "; " + markers + ")");
                }
            }

            if (!result.isEmpty()) return result.toArray(new String[0]);
            if (groups.isEmpty()) {
                return new String[]{"__INFO__\tgetevent ran, but Shizuku returned no /dev/input/event* devices. The tablet may be blocking device enumeration."};
            }
            StringBuilder diagnostic = new StringBuilder("No obvious gamepad matched. Devices visible to Shizuku: ");
            diagnostic.append(String.join(" | ", visibleNodes));
            if (groups.size() > visibleNodes.size()) diagnostic.append(" | … and ").append(groups.size() - visibleNodes.size()).append(" more");
            return new String[]{"__INFO__\t" + diagnostic};
        } catch (Exception e) {
            return new String[]{"__ERROR__\tCould not run getevent: " + e.getClass().getSimpleName() + ": " + e.getMessage()};
        } finally {
            if (process != null) process.destroy();
        }
    }

    private static boolean looksLikeGamepad(DeviceBlock block) {
        String name = block.name == null ? "" : block.name.toLowerCase(Locale.ROOT);
        String caps = block.capabilities.toString().toUpperCase(Locale.ROOT);
        if (name.contains("flydigi") || name.contains("vader") || name.contains("gamepad") ||
                name.contains("joystick") || name.contains("controller")) return true;
        boolean x = caps.contains("ABS_X") || caps.matches("(?s).*\\bX\\b.*");
        boolean y = caps.contains("ABS_Y") || caps.matches("(?s).*\\bY\\b.*");
        boolean button = caps.contains("BTN_GAMEPAD") || caps.contains("BTN_SOUTH") ||
                caps.contains("BTN_A ") || caps.contains("BTN_A\n") || caps.contains("BTN_JOYSTICK");
        return x && y && button;
    }

    private static String capabilitySummary(String caps) {
        String upper = caps.toUpperCase(Locale.ROOT);
        List<String> labels = new ArrayList<>();
        if (upper.contains("KEY (")) labels.add("KEY");
        if (upper.contains("ABS (")) labels.add("ABS");
        if (upper.contains("REL (")) labels.add("REL");
        if (upper.contains("BTN_") || upper.contains("KEY_") || upper.contains("BTN ")) labels.add("buttons/keys");
        if (upper.contains("ABS_X") || upper.matches("(?s).*\\bX\\b.*")) labels.add("X");
        if (upper.contains("ABS_Y") || upper.matches("(?s).*\\bY\\b.*")) labels.add("Y");
        return labels.isEmpty() ? "capabilities not parsed" : String.join(",", labels);
    }

    @Override
    public synchronized boolean startBridge(String[] paths, String name) throws RemoteException {
        if (paths == null || paths.length == 0) {
            localStatus = "ERROR: no input event path selected";
            return false;
        }
        Thread existing = bridgeThread;
        if (existing != null && existing.isAlive()) {
            localStatus = "Bridge is already running";
            return false;
        }
        for (String path : paths) {
            if (path == null || !path.startsWith("/dev/input/event")) {
                localStatus = "ERROR: invalid event path";
                return false;
            }
        }
        localStatus = "Starting bridge...";
        bridgeThread = new Thread(() -> {
            try {
                NativeBridge.runBridge(paths, name == null ? "Physical gamepad" : name);
            } catch (Throwable t) {
                localStatus = "ERROR: native bridge failed: " + t.getClass().getSimpleName() + ": " + t.getMessage();
            } finally {
                if (localStatus.startsWith("Starting")) localStatus = NativeBridge.getBridgeStatus();
            }
        }, "VaderXboxBridgeWorker");
        bridgeThread.start();
        return true;
    }

    @Override
    public void stopBridge() throws RemoteException {
        localStatus = "Stopping...";
        try {
            NativeBridge.stopBridge();
        } catch (Throwable t) {
            localStatus = "ERROR while stopping: " + t.getMessage();
        }
    }

    @Override
    public String getBridgeStatus() throws RemoteException {
        try {
            String nativeStatus = NativeBridge.getBridgeStatus();
            if (nativeStatus != null && !nativeStatus.trim().isEmpty() && !"Idle".equals(nativeStatus)) {
                return nativeStatus;
            }
        } catch (Throwable t) {
            return "ERROR: native library unavailable: " + t.getClass().getSimpleName() + ": " + t.getMessage();
        }
        return localStatus;
    }

    private static final class DeviceBlock {
        String path;
        String name;
        final List<String> paths = new ArrayList<>();
        final StringBuilder capabilities = new StringBuilder();
    }
}
