# Vader Xbox Bridge — USB Direct Test 0.2.0

Đây là **bộ mã nguồn + workflow build APK trên GitHub**, chưa phải APK đã build/kiểm thử. Môi trường hiện tại không có Android SDK/NDK để tạo APK cài trực tiếp.

## Bản này thay đổi gì?

Kết quả `dumpsys usb` trên Xiaomi Pad 6 cho thấy thiết bị `VID 37D7 / PID 2401`, interface 0 là giao diện vendor/Xbox-like với interrupt-IN endpoint `0x81`; `event13` lại là giao diện chuột. Bản nguồn này thêm chế độ đọc endpoint USB trực tiếp qua Android USB Host API, rồi chuyển trạng thái nút/trục sang `/dev/uinput` trong Shizuku shell service. Báo cáo chuẩn Xbox dài 20 byte được giải mã để chuyển nút, D-pad, cần analog và cò analog.

## Tạo APK bằng điện thoại/tablet

1. Mở https://github.com/new và tạo repository **Private**.
2. Trong repo mới, chọn **Add file → Upload files**, tải `VaderXboxBridge-USB-Direct-Source.zip` lên rồi Commit.
3. Tạo file `.github/workflows/build-apk.yml` trong repo.
4. Mở `VaderXboxBridge-GitHub-Build-Workflow.yml` trong bộ kit, sao chép toàn bộ nội dung vào file workflow ở bước 3, rồi Commit.
5. Vào tab **Actions**, mở lượt chạy **Build VaderXboxBridge USB Direct Test APK**.
6. Khi job thành công, tải artifact `vaderxboxbridge-usb-direct-test-apk`, giải nén artifact và cài `app-debug.apk` trên Xiaomi Pad 6.

## Thử nghiệm app

1. Giữ Shizuku đang hoạt động và mở app.
2. Nhấn **Connect Shizuku**, đợi dòng `Shizuku connected`.
3. Nhấn **Start USB-direct Vader bridge**, rồi chấp nhận hộp thoại quyền USB của Android.
4. Nếu hiện `RUNNING — direct USB reports decoded`, thử bằng một app kiểm tra tay cầm trước khi mở game.
5. Dùng **Stop bridge** khi kết thúc.

## Giới hạn cần nói rõ

- Mã nguồn này chưa được build hoặc kiểm tra trên thiết bị thật. Phần C++ đã qua kiểm tra cú pháp; chưa xác nhận APK compile thành công hay endpoint `0x81` có phát báo cáo trên mọi firmware.
- Bản đầu tập trung vào báo cáo Xbox chuẩn trên interface 0; gyro, M1–M4, rumble và giao diện mở rộng FFA0 chưa triển khai.
- Nếu app báo `cannot open /dev/uinput`, firmware Android có thể chặn tạo tay cầm ảo không-root; đường đọc USB không thể vượt qua giới hạn đó.
- Nếu interface 0 mở được nhưng không gửi báo cáo, cần triển khai giao thức mở rộng FFA0; không cần lặp lại lệnh Termux cũ.
