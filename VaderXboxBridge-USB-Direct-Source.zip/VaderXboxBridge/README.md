# Vader Xbox Bridge 0.3.0 — Experimental USB XInput bridge

The 0.3.0 source fixes a confirmed defect in 0.2.0: the previous version sent only one of the three documented wired XInput control-IN startup requests. This version sends the three-request sequence, records each transfer result, reads the interrupt-IN endpoint, and only creates the Shizuku `/dev/uinput` Xbox 360 virtual device after receiving a valid `00 14` report. Diagnostics distinguish no USB packets, unexpected report formats, and virtual-device creation failure.

**This is source code, not a built or device-tested APK.** The current environment has no Android SDK/NDK and no connected Xiaomi Pad 6, so Android compilation, actual USB handshakes, `uinput` permissions, and game compatibility remain unverified. See `README_VI.md` for the Vietnamese explanation and testing instructions.

Current mapping: standard Xbox buttons, D-pad, analog triggers, and both sticks. Gyro, rumble, and M1–M4/Fn are not implemented.
