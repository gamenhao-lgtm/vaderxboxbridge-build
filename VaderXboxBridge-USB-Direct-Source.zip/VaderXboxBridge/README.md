# Vader Xbox Bridge — USB Direct Test 0.2.0

Experimental Android USB Host reader for Flydigi Vader 5 Pro (VID 0x37D7, PID 0x2401), forwarding the interface-0 Xbox-like input report to a virtual Xbox device created by a Shizuku shell-UID service. The legacy Linux evdev bridge remains available.

This source has not been built or verified on the target Xiaomi Pad 6. It initially reads the 20-byte report from interrupt-IN endpoint 0x81; FFA0 extended reports, gyro, extra paddles, and rumble are not yet implemented.
