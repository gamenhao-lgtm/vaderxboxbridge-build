@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "GRADLE_VERSION=8.10.2"
set "TOOLS_DIR=%ROOT%.tools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%TOOLS_DIR%\gradle-%GRADLE_VERSION%-bin.zip"

if not defined ANDROID_HOME if defined ANDROID_SDK_ROOT set "ANDROID_HOME=%ANDROID_SDK_ROOT%"
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk\platforms\android-35\android.jar" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_SDK_ROOT if defined ANDROID_HOME set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

if not defined ANDROID_HOME (
  echo ERROR: Android SDK not found. Install Android Studio and Android SDK Platform 35 first.
  echo Then set ANDROID_HOME to your Android SDK folder, usually %%LOCALAPPDATA%%\Android\Sdk.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
  echo ERROR: Android SDK Platform 35 is missing. Install it in Android Studio - Tools - SDK Manager.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%\ndk\27.0.12077973" (
  echo ERROR: NDK 27.0.12077973 is missing. Install it in Android Studio - Tools - SDK Manager - SDK Tools.
  pause
  exit /b 1
)
if not exist "%ANDROID_HOME%\cmake\3.22.1" (
  echo ERROR: CMake 3.22.1 is missing. Install it in Android Studio - Tools - SDK Manager - SDK Tools.
  pause
  exit /b 1
)

if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
  echo Downloading official Gradle %GRADLE_VERSION% distribution...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
  if errorlevel 1 (
    echo ERROR: Gradle download failed. Check network access and try again.
    pause
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%TOOLS_DIR%' -Force"
  if errorlevel 1 (
    echo ERROR: Could not extract Gradle.
    pause
    exit /b 1
  )
)

pushd "%ROOT%"
call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" assembleDebug
set "BUILD_RESULT=%ERRORLEVEL%"
popd
if not "%BUILD_RESULT%"=="0" (
  echo.
  echo BUILD FAILED. Copy the full error text before closing this window.
  pause
  exit /b %BUILD_RESULT%
)
echo.
echo BUILD SUCCESS. APK: %ROOT%app\build\outputs\apk\debug\app-debug.apk
pause
