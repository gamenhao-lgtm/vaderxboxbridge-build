# Vader Xbox Bridge 0.3.0 — USB XInput có chẩn đoán (thử nghiệm)

## Những gì đã sửa sau khi rà soát bản 0.2.0

Bản 0.2.0 chỉ gửi **1/3** yêu cầu khởi tạo USB mà giao thức XInput có dây cần. Bản 0.3.0 gửi đủ chuỗi control-IN được ghi nhận cho Vader 5 Pro: `C1/01/0100`, `C1/01/0000`, `C0/01/0000`. Kết quả từng yêu cầu được ghi trong trạng thái app.

Luồng mới là:

`Vader 5 Pro USB OTG (37D7:2401) → USB Host → 3 handshake → interrupt IN report 00 14 → Shizuku → /dev/uinput → Xbox 360 ảo`

Điểm thay đổi quan trọng: **không tạo gamepad ảo ngay khi mở cổng USB**. App chờ nhận report XInput hợp lệ trước, rồi mới thử tạo thiết bị ảo. Nhờ vậy, trạng thái phân biệt được vấn đề giao tiếp USB với vấn đề quyền `/dev/uinput`. Nếu endpoint không trả gói hoặc trả gói sai định dạng, app hiển thị kết quả handshake và mẫu gói đầu tiên.

## Trạng thái kiểm chứng — đọc trước khi cài

Đây vẫn là **mã nguồn, không phải APK đã build và kiểm thử trên Xiaomi Pad 6**. Môi trường làm việc hiện không có Android SDK/NDK và không có máy tính bảng kết nối để xác minh USB OTG. Tôi không thể trung thực bảo đảm bản này chạy được trên máy của bạn.

Đã xác minh bằng rà soát mã nguồn: đúng VID/PID `37D7:2401`; chọn interface `FF/5D/01`; chọn endpoint interrupt IN; gửi đủ ba control-IN handshake; chờ report có header `00 14`; chỉ sau đó mới tạo thiết bị `/dev/uinput`; báo riêng lỗi không có dữ liệu, định dạng report lạ và không tạo được gamepad ảo.

Chưa thể xác minh trong môi trường này: biên dịch APK Android hoàn chỉnh; kết quả handshake trên đúng firmware tay cầm của bạn; quyền USB trên MIUI/HyperOS; quyền shell mở `/dev/uinput`; và việc từng game có chấp nhận thiết bị ảo hay không.

## Cách dùng sau khi đã build

1. Cắm Vader 5 Pro qua cáp OTG và mở Shizuku ở trạng thái Running.
2. Mở app, nhấn **Kết nối Shizuku**.
3. Nhấn **Bắt đầu cầu nối USB → Xbox** và cấp quyền USB khi Android hỏi.
4. Đọc trạng thái: cần thấy app đã nhận report XInput và tạo gamepad ảo. Nếu không có gói USB, app sẽ hiện kết quả handshake; nếu USB có gói nhưng sai định dạng, app sẽ hiện mẫu byte; nếu hệ thống chặn `/dev/uinput`, app sẽ báo lỗi tạo gamepad ảo.
5. Dùng app kiểm tra tay cầm để thử nút/cần analog trước khi mở game.
6. Nhấn **Dừng cầu nối** trước khi rút cáp.

Nếu APK báo xung đột chữ ký khi cập nhật, có thể phải gỡ bản Vader Xbox Bridge cũ trước. Việc này chỉ tác động đến app bridge, không thay đổi firmware tay cầm.

## Giới hạn

- Mới chuyển nút chuẩn Xbox, D-pad, trigger analog và hai cần analog.
- Gyro, rung, M1–M4/Fn chưa được triển khai.
- Có thể không chạy nếu firmware không cho UID shell tạo `/dev/uinput`, kể cả khi USB đọc thành công.
- Build APK thành công chỉ xác nhận compile, không đồng nghĩa đã xác nhận hoạt động trên máy thật hoặc tương thích với mọi game Android.
