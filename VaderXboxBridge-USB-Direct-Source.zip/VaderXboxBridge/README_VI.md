# Vader Xbox Bridge — USB Direct Test 0.2.0

## Mục tiêu bản thử này

Bản 0.1.x chỉ đọc `/dev/input/event*`; trên Xiaomi Pad 6, Vader 5 Pro xuất hiện tại `event13` dưới dạng chuột, nên đường đó không có trục/nút gamepad. Bản này thêm một đường khác: Android USB Host API đọc trực tiếp **USB VID `0x37D7`, PID `0x2401`, interface 0, interrupt-IN endpoint `0x81`**. Báo cáo 20 byte kiểu Xbox được chuyển qua Shizuku sang `/dev/uinput` để tạo tay cầm Xbox ảo.

Thông tin giao diện/định dạng dựa trên tài liệu giao thức cộng đồng cho Vader 5 Pro. Đây là bản thử nghiệm: chưa được biên dịch và kiểm tra trên Xiaomi Pad 6 của người dùng, nên không cam kết endpoint có phát báo cáo trên mọi firmware/chế độ kết nối.

## Cách dùng sau khi tạo APK

1. Giữ Shizuku đang chạy và cấp quyền cho app như trước.
2. Mở Vader Xbox Bridge, bấm **Connect Shizuku** và đợi trạng thái `Shizuku connected`.
3. Bấm **Start USB-direct Vader bridge**. Android sẽ hiện hộp thoại USB permission; chọn cho phép.
4. Trạng thái mong muốn là `RUNNING — direct USB reports decoded: ...`. Khi đó kiểm tra bằng app gamepad tester trước khi mở game.
5. Dùng **Stop bridge** để đóng USB interface và thiết bị Xbox ảo.

Nút **Start event-node bridge (legacy)** vẫn còn nhưng không phải đường dành cho Vader ở cấu hình hiện tại.

## Giới hạn

- Chưa hỗ trợ đọc giao diện mở rộng FFA0/gyro/M1–M4/rumble; bản này tập trung vào báo cáo Xbox chính ở interface 0.
- Nếu app báo `cannot open /dev/uinput`, firmware Android có thể chặn tạo thiết bị gamepad ảo không-root; đường đọc USB không thể vượt qua giới hạn đó.
- Nếu interface 0 mở được nhưng không có báo cáo, firmware có thể cần đường giao diện mở rộng FFA0; khi đó status sẽ phân biệt được trường hợp không có dữ liệu và trường hợp packet không khớp.
- Đây là mã nguồn, không phải APK cài sẵn đã xác minh.
