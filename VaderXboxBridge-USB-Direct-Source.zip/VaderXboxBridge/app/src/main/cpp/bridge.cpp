#include <jni.h>
#include <android/log.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdint>
#include <cstddef>
#include <algorithm>
#include <array>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "VaderXboxBridge"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {
std::atomic<bool> g_stop{false};
std::atomic<bool> g_running{false};
std::mutex g_status_mutex;
std::string g_status = "Idle";
std::mutex g_usb_mutex;
std::atomic<bool> g_usb_running{false};
int g_usb_output_fd = -1;
uint32_t g_usb_button_state = 0xffffffffu;

void setStatus(const std::string &value) {
    std::lock_guard<std::mutex> lock(g_status_mutex);
    g_status = value;
    LOGI("%s", value.c_str());
}

std::string getStatusCopy() {
    std::lock_guard<std::mutex> lock(g_status_mutex);
    return g_status;
}

bool isPassThroughKey(int code) {
    switch (code) {
        case BTN_SOUTH: case BTN_EAST: case BTN_NORTH: case BTN_WEST:
        case BTN_TL: case BTN_TR: case BTN_TL2: case BTN_TR2:
        case BTN_SELECT: case BTN_START: case BTN_MODE:
        case BTN_THUMBL: case BTN_THUMBR:
        case BTN_DPAD_UP: case BTN_DPAD_DOWN: case BTN_DPAD_LEFT: case BTN_DPAD_RIGHT:
            return true;
        default:
            return code >= BTN_TRIGGER_HAPPY1 && code <= BTN_TRIGGER_HAPPY40;
    }
}

int mapAbsCode(int code) {
    switch (code) {
        case ABS_X: case ABS_Y: case ABS_RX: case ABS_RY:
        case ABS_Z: case ABS_RZ: case ABS_HAT0X: case ABS_HAT0Y:
            return code;
        case ABS_BRAKE: case ABS_THROTTLE:
            return ABS_Z;
        case ABS_GAS: case ABS_RUDDER:
            return ABS_RZ;
        default:
            return -1;
    }
}

bool isTriggerAxis(int targetCode) {
    return targetCode == ABS_Z || targetCode == ABS_RZ;
}

bool isHatAxis(int targetCode) {
    return targetCode == ABS_HAT0X || targetCode == ABS_HAT0Y;
}

int normalizeAxis(const struct input_absinfo &info, bool hasInfo, int targetCode, int value) {
    if (isHatAxis(targetCode)) {
        if (hasInfo && info.minimum <= -1 && info.maximum >= 1) {
            return std::clamp(value, -1, 1);
        }
        if (!hasInfo) return std::clamp(value, -1, 1);
        if (value <= info.minimum) return -1;
        if (value >= info.maximum) return 1;
        return 0;
    }

    if (!hasInfo) {
        return isTriggerAxis(targetCode) ? std::clamp(value, 0, 255)
                                         : std::clamp(value, -32768, 32767);
    }

    const int64_t range = static_cast<int64_t>(info.maximum) - info.minimum;
    const int64_t offset = static_cast<int64_t>(value) - info.minimum;
    if (isTriggerAxis(targetCode)) {
        return static_cast<int>(std::clamp<int64_t>((offset * 255 + range / 2) / range, 0, 255));
    }
    return static_cast<int>(std::clamp<int64_t>(-32768 + (offset * 65535 + range / 2) / range,
                                                -32768, 32767));
}

bool writeFully(int fd, const void *buffer, size_t size) {
    const auto *bytes = static_cast<const unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < size) {
        ssize_t written = write(fd, bytes + offset, size - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) return false;
        offset += static_cast<size_t>(written);
    }
    return true;
}

bool emitEvent(int fd, uint16_t type, uint16_t code, int32_t value) {
    struct input_event ev{};
    gettimeofday(&ev.time, nullptr);
    ev.type = type;
    ev.code = code;
    ev.value = value;
    return writeFully(fd, &ev, sizeof(ev));
}

bool emitSync(int fd) {
    return emitEvent(fd, EV_SYN, SYN_REPORT, 0);
}

bool configureUinput(int fd, std::string &why) {
    auto set = [&](unsigned long request, int value, const char *label) -> bool {
        if (ioctl(fd, request, value) < 0) {
            why = std::string(label) + ": " + strerror(errno);
            return false;
        }
        return true;
    };

    if (!set(UI_SET_EVBIT, EV_SYN, "UI_SET_EVBIT EV_SYN") ||
        !set(UI_SET_EVBIT, EV_KEY, "UI_SET_EVBIT EV_KEY") ||
        !set(UI_SET_EVBIT, EV_ABS, "UI_SET_EVBIT EV_ABS")) return false;

    const int keyBits[] = {
        BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST,
        BTN_TL, BTN_TR, BTN_TL2, BTN_TR2,
        BTN_SELECT, BTN_START, BTN_MODE, BTN_THUMBL, BTN_THUMBR,
        BTN_DPAD_UP, BTN_DPAD_DOWN, BTN_DPAD_LEFT, BTN_DPAD_RIGHT
    };
    for (int key : keyBits) {
        if (!set(UI_SET_KEYBIT, key, "UI_SET_KEYBIT")) return false;
    }
    for (int key = BTN_TRIGGER_HAPPY1; key <= BTN_TRIGGER_HAPPY40; ++key) {
        if (!set(UI_SET_KEYBIT, key, "UI_SET_KEYBIT trigger-happy")) return false;
    }

    const int absBits[] = {ABS_X, ABS_Y, ABS_RX, ABS_RY, ABS_Z, ABS_RZ, ABS_HAT0X, ABS_HAT0Y};
    for (int axis : absBits) {
        if (!set(UI_SET_ABSBIT, axis, "UI_SET_ABSBIT")) return false;
    }

    struct uinput_user_dev setup{};
    strncpy(setup.name, "Microsoft X-Box 360 pad", UINPUT_MAX_NAME_SIZE - 1);
    setup.id.bustype = BUS_USB;
    setup.id.vendor = 0x045e;
    setup.id.product = 0x028e;
    setup.id.version = 0x0114;

    auto setRange = [&](int axis, int minVal, int maxVal, int fuzz, int flat) {
        setup.absmin[axis] = minVal;
        setup.absmax[axis] = maxVal;
        setup.absfuzz[axis] = fuzz;
        setup.absflat[axis] = flat;
    };
    setRange(ABS_X, -32768, 32767, 16, 128);
    setRange(ABS_Y, -32768, 32767, 16, 128);
    setRange(ABS_RX, -32768, 32767, 16, 128);
    setRange(ABS_RY, -32768, 32767, 16, 128);
    setRange(ABS_Z, 0, 255, 0, 0);
    setRange(ABS_RZ, 0, 255, 0, 0);
    setRange(ABS_HAT0X, -1, 1, 0, 0);
    setRange(ABS_HAT0Y, -1, 1, 0, 0);

    if (!writeFully(fd, &setup, sizeof(setup))) {
        why = std::string("write uinput setup: ") + strerror(errno);
        return false;
    }
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
        why = std::string("UI_DEV_CREATE: ") + strerror(errno);
        return false;
    }
    return true;
}

void releaseFds(std::vector<int> &inputFds, int outputFd, bool outputCreated) {
    if (outputFd >= 0 && outputCreated) ioctl(outputFd, UI_DEV_DESTROY);
    if (outputFd >= 0) close(outputFd);
    for (int fd : inputFds) {
        if (fd >= 0) {
            ioctl(fd, EVIOCGRAB, 0);
            close(fd);
        }
    }
    inputFds.clear();
}

int16_t readLe16(const uint8_t *data, size_t offset) {
    uint16_t value = static_cast<uint16_t>(data[offset]) |
                     (static_cast<uint16_t>(data[offset + 1]) << 8);
    return static_cast<int16_t>(value);
}

bool emitKeyIfChanged(int fd, uint32_t buttonState, unsigned int bit, uint16_t code) {
    bool now = (buttonState & (1u << bit)) != 0;
    bool before = (g_usb_button_state & (1u << bit)) != 0;
    if (g_usb_button_state == 0xffffffffu || now != before) {
        return emitEvent(fd, EV_KEY, code, now ? 1 : 0);
    }
    return true;
}

// Pushes a standard 20-byte Flydigi Xbox-compatible report (interface 0 / EP 0x81).
bool pushStandardUsbReportLocked(const uint8_t *data, size_t length) {
    if (g_usb_output_fd < 0 || length < 14 || data[0] != 0x00) return false;
    const uint8_t misc = data[2];
    const uint8_t buttons = data[3];
    uint32_t state = 0;
    auto mark = [&](unsigned bit, bool pressed) { if (pressed) state |= (1u << bit); };
    // Button bit slots are internal to this bridge; emitKeyIfChanged maps them to evdev.
    mark(0, (misc & 0x01) != 0); // D-pad up
    mark(1, (misc & 0x02) != 0); // D-pad down
    mark(2, (misc & 0x04) != 0); // D-pad left
    mark(3, (misc & 0x08) != 0); // D-pad right
    mark(4, (misc & 0x10) != 0); // Start
    mark(5, (misc & 0x20) != 0); // Select / Back
    mark(6, (misc & 0x40) != 0); // Left stick click
    mark(7, (misc & 0x80) != 0); // Right stick click
    mark(8, (buttons & 0x01) != 0); // LB
    mark(9, (buttons & 0x02) != 0); // RB
    mark(10, (buttons & 0x04) != 0); // Home / Guide
    mark(11, (buttons & 0x10) != 0); // A
    mark(12, (buttons & 0x20) != 0); // B
    mark(13, (buttons & 0x40) != 0); // X
    mark(14, (buttons & 0x80) != 0); // Y

    const struct { unsigned bit; uint16_t code; } keys[] = {
        {0, BTN_DPAD_UP}, {1, BTN_DPAD_DOWN}, {2, BTN_DPAD_LEFT}, {3, BTN_DPAD_RIGHT},
        {4, BTN_START}, {5, BTN_SELECT}, {6, BTN_THUMBL}, {7, BTN_THUMBR},
        {8, BTN_TL}, {9, BTN_TR}, {10, BTN_MODE}, {11, BTN_SOUTH}, {12, BTN_EAST},
        {13, BTN_NORTH}, {14, BTN_WEST}
    };
    for (const auto &key : keys) {
        if (!emitKeyIfChanged(g_usb_output_fd, state, key.bit, key.code)) {
            setStatus(std::string("ERROR: USB-report button write failed: ") + strerror(errno));
            return false;
        }
    }
    g_usb_button_state = state;

    const int16_t lx = readLe16(data, 6);
    const int16_t ly = readLe16(data, 8);
    const int16_t rx = readLe16(data, 10);
    const int16_t ry = readLe16(data, 12);
    const int lt = data[4];
    const int rt = data[5];
    if (!emitEvent(g_usb_output_fd, EV_ABS, ABS_X, lx) ||
        !emitEvent(g_usb_output_fd, EV_ABS, ABS_Y, std::clamp(-static_cast<int>(ly), -32768, 32767)) ||
        !emitEvent(g_usb_output_fd, EV_ABS, ABS_RX, rx) ||
        !emitEvent(g_usb_output_fd, EV_ABS, ABS_RY, std::clamp(-static_cast<int>(ry), -32768, 32767)) ||
        !emitEvent(g_usb_output_fd, EV_ABS, ABS_Z, lt) ||
        !emitEvent(g_usb_output_fd, EV_ABS, ABS_RZ, rt) ||
        !emitSync(g_usb_output_fd)) {
        setStatus(std::string("ERROR: USB-report axis write failed: ") + strerror(errno));
        return false;
    }
    return true;
}

} // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_runBridge(JNIEnv *env, jclass,
                                                         jobjectArray pathsArray,
                                                         jstring physicalName) {
    if (g_usb_running.load()) {
        setStatus("ERROR: stop USB-direct mode before starting the event-node bridge");
        return;
    }
    if (g_running.exchange(true)) {
        setStatus("ERROR: bridge is already running");
        return;
    }
    g_stop.store(false);

    const char *nameChars = physicalName ? env->GetStringUTFChars(physicalName, nullptr) : nullptr;
    std::string name = nameChars ? nameChars : "Physical gamepad";
    if (nameChars) env->ReleaseStringUTFChars(physicalName, nameChars);

    if (pathsArray == nullptr || env->GetArrayLength(pathsArray) == 0) {
        setStatus("ERROR: no input paths supplied");
        g_running.store(false);
        return;
    }

    std::vector<int> inputFds;
    std::vector<std::string> inputPaths;
    const jsize pathCount = env->GetArrayLength(pathsArray);
    inputFds.reserve(static_cast<size_t>(pathCount));
    inputPaths.reserve(static_cast<size_t>(pathCount));

    setStatus("Opening controller events for " + name + "...");
    for (jsize i = 0; i < pathCount; ++i) {
        jstring pathString = static_cast<jstring>(env->GetObjectArrayElement(pathsArray, i));
        const char *pathChars = env->GetStringUTFChars(pathString, nullptr);
        std::string path = pathChars ? pathChars : "";
        if (pathChars) env->ReleaseStringUTFChars(pathString, pathChars);
        env->DeleteLocalRef(pathString);

        if (path.rfind("/dev/input/event", 0) != 0) {
            setStatus("ERROR: rejected non-input path: " + path);
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) {
            setStatus("ERROR: cannot open " + path + ": " + strerror(errno) + ". Shizuku shell may not have permission on this tablet.");
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
        inputFds.push_back(fd);
        inputPaths.push_back(path);
    }

    for (size_t i = 0; i < inputFds.size(); ++i) {
        if (ioctl(inputFds[i], EVIOCGRAB, 1) < 0) {
            setStatus("ERROR: cannot exclusively grab " + inputPaths[i] + ": " + strerror(errno));
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
    }

    // Cache physical axis ranges once, not once per frame; this reduces input-path overhead.
    std::vector<std::array<struct input_absinfo, ABS_CNT>> absInfos(inputFds.size());
    std::vector<std::array<bool, ABS_CNT>> absValid(inputFds.size());
    for (size_t i = 0; i < inputFds.size(); ++i) {
        absInfos[i].fill(input_absinfo{});
        absValid[i].fill(false);
        for (int code = 0; code <= ABS_MAX; ++code) {
            struct input_absinfo info{};
            if (ioctl(inputFds[i], EVIOCGABS(code), &info) == 0 && info.maximum > info.minimum) {
                absInfos[i][static_cast<size_t>(code)] = info;
                absValid[i][static_cast<size_t>(code)] = true;
            }
        }
    }

    int outputFd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (outputFd < 0) {
        setStatus(std::string("ERROR: cannot open /dev/uinput: ") + strerror(errno) +
                  ". If this is Permission denied, the tablet firmware blocks rootless virtual gamepads.");
        releaseFds(inputFds, -1, false);
        g_running.store(false);
        return;
    }

    std::string reason;
    if (!configureUinput(outputFd, reason)) {
        setStatus("ERROR: virtual Xbox creation failed: " + reason);
        releaseFds(inputFds, outputFd, false);
        g_running.store(false);
        return;
    }

    setStatus("RUNNING — virtual Xbox created; physical events grabbed. Test the Xbox device in a gamepad tester.");
    LOGI("Bridge started with %zu event node(s)", inputFds.size());

    std::vector<pollfd> pollFds(inputFds.size());
    for (size_t i = 0; i < inputFds.size(); ++i) {
        pollFds[i].fd = inputFds[i];
        pollFds[i].events = POLLIN;
        pollFds[i].revents = 0;
    }

    bool disconnected = false;
    bool failed = false;
    while (!g_stop.load()) {
        int ready = poll(pollFds.data(), static_cast<nfds_t>(pollFds.size()), 100);
        if (ready < 0) {
            if (errno == EINTR) continue;
            setStatus(std::string("ERROR: poll failed: ") + strerror(errno));
            failed = true;
            break;
        }
        if (ready == 0) continue;

        for (size_t i = 0; i < pollFds.size() && !g_stop.load(); ++i) {
            if (pollFds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                setStatus("Controller disconnected or input node closed: " + inputPaths[i]);
                disconnected = true;
                g_stop.store(true);
                break;
            }
            if (!(pollFds[i].revents & POLLIN)) continue;

            struct input_event events[32];
            ssize_t bytes = read(inputFds[i], events, sizeof(events));
            if (bytes < 0) {
                if (errno == EINTR || errno == EAGAIN) continue;
                setStatus(std::string("ERROR: input read failed: ") + strerror(errno));
                failed = true;
                g_stop.store(true);
                break;
            }
            if (bytes == 0) {
                setStatus("Controller input stream ended.");
                disconnected = true;
                g_stop.store(true);
                break;
            }
            const size_t count = static_cast<size_t>(bytes) / sizeof(struct input_event);
            for (size_t j = 0; j < count; ++j) {
                const struct input_event &ev = events[j];
                if (ev.type == EV_KEY) {
                    if (isPassThroughKey(ev.code)) {
                        if (!emitEvent(outputFd, EV_KEY, ev.code, ev.value)) {
                            setStatus(std::string("ERROR: virtual-key write failed: ") + strerror(errno));
                            failed = true;
                            g_stop.store(true);
                            break;
                        }
                    }
                } else if (ev.type == EV_ABS) {
                    int target = mapAbsCode(ev.code);
                    if (target >= 0) {
                        int mapped = normalizeAxis(absInfos[i][ev.code], absValid[i][ev.code], target, ev.value);
                        if (!emitEvent(outputFd, EV_ABS, static_cast<uint16_t>(target), mapped)) {
                            setStatus(std::string("ERROR: virtual-axis write failed: ") + strerror(errno));
                            failed = true;
                            g_stop.store(true);
                            break;
                        }
                    }
                } else if (ev.type == EV_SYN && ev.code == SYN_REPORT) {
                    if (!emitSync(outputFd)) {
                        setStatus(std::string("ERROR: virtual-sync write failed: ") + strerror(errno));
                        failed = true;
                        g_stop.store(true);
                        break;
                    }
                }
            }
            pollFds[i].revents = 0;
        }
    }

    releaseFds(inputFds, outputFd, true);
    if (g_stop.load() && !disconnected && !failed) setStatus("Stopped. Controller events have been released.");
    g_running.store(false);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_stopBridge(JNIEnv *, jclass) {
    if (g_running.load()) {
        g_stop.store(true);
        setStatus("Stopping bridge…");
    } else {
        setStatus("Stopped");
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_getBridgeStatus(JNIEnv *env, jclass) {
    const std::string status = getStatusCopy();
    return env->NewStringUTF(status.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_startUsbReportBridge(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_usb_mutex);
    if (g_usb_running.load()) {
        setStatus("USB-direct bridge is already running");
        return JNI_TRUE;
    }
    if (g_running.load()) {
        setStatus("ERROR: stop the evdev bridge before starting USB-direct mode");
        return JNI_FALSE;
    }
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) {
        setStatus(std::string("ERROR: cannot open /dev/uinput for USB-direct mode: ") + strerror(errno) +
                  ". The tablet firmware may block rootless virtual gamepads.");
        return JNI_FALSE;
    }
    std::string reason;
    if (!configureUinput(fd, reason)) {
        setStatus("ERROR: virtual Xbox creation failed: " + reason);
        ioctl(fd, UI_DEV_DESTROY);
        close(fd);
        return JNI_FALSE;
    }
    g_usb_output_fd = fd;
    g_usb_button_state = 0xffffffffu;
    g_usb_running.store(true);
    setStatus("RUNNING — virtual Xbox created; waiting for direct USB input reports");
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_pushUsbReport(JNIEnv *env, jclass, jbyteArray reportArray) {
    if (reportArray == nullptr) return JNI_FALSE;
    const jsize length = env->GetArrayLength(reportArray);
    if (length < 14) return JNI_FALSE;
    std::vector<uint8_t> bytes(static_cast<size_t>(length));
    env->GetByteArrayRegion(reportArray, 0, length, reinterpret_cast<jbyte *>(bytes.data()));
    if (env->ExceptionCheck()) { env->ExceptionClear(); return JNI_FALSE; }
    std::lock_guard<std::mutex> lock(g_usb_mutex);
    if (!g_usb_running.load() || g_usb_output_fd < 0) return JNI_FALSE;
    bool accepted = pushStandardUsbReportLocked(bytes.data(), bytes.size());
    if (accepted && getStatusCopy().find("waiting for direct USB input reports") != std::string::npos) {
        setStatus("RUNNING — direct USB input reports received; virtual Xbox is active");
    }
    return accepted ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_stopUsbReportBridge(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_usb_mutex);
    if (g_usb_output_fd >= 0) {
        ioctl(g_usb_output_fd, UI_DEV_DESTROY);
        close(g_usb_output_fd);
        g_usb_output_fd = -1;
    }
    if (g_usb_running.exchange(false)) {
        g_usb_button_state = 0xffffffffu;
        setStatus("Stopped USB-direct bridge");
    }
}

