#include <jni.h>
#include <android/log.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "VaderXboxBridge"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {
std::atomic<bool> g_stop{false};
std::atomic<bool> g_running{false};
std::mutex g_status_mutex;
std::string g_status = "Idle";

// Direct USB path: Java reads the controller's interrupt endpoint and sends the
// standard XInput packet here over Shizuku Binder. Access is serialized because
// reports may arrive while the user presses Stop.
std::mutex g_report_mutex;
int g_report_fd = -1;
bool g_report_mode = false;
bool g_report_has_data = false;

void setStatus(const std::string &value) {
    std::lock_guard<std::mutex> lock(g_status_mutex);
    g_status = value;
    LOGI("%s", value.c_str());
}

std::string getStatusCopy() {
    std::lock_guard<std::mutex> lock(g_status_mutex);
    return g_status;
}

bool isPassThroughKey(int code) {
    switch (code) {
        case BTN_SOUTH: case BTN_EAST: case BTN_NORTH: case BTN_WEST:
        case BTN_TL: case BTN_TR: case BTN_TL2: case BTN_TR2:
        case BTN_SELECT: case BTN_START: case BTN_MODE:
        case BTN_THUMBL: case BTN_THUMBR:
        case BTN_DPAD_UP: case BTN_DPAD_DOWN: case BTN_DPAD_LEFT: case BTN_DPAD_RIGHT:
            return true;
        default:
            return code >= BTN_TRIGGER_HAPPY1 && code <= BTN_TRIGGER_HAPPY40;
    }
}

int mapAbsCode(int code) {
    switch (code) {
        case ABS_X: case ABS_Y: case ABS_RX: case ABS_RY:
        case ABS_Z: case ABS_RZ: case ABS_HAT0X: case ABS_HAT0Y:
            return code;
        case ABS_BRAKE: case ABS_THROTTLE:
            return ABS_Z;
        case ABS_GAS: case ABS_RUDDER:
            return ABS_RZ;
        default:
            return -1;
    }
}

bool isTriggerAxis(int targetCode) {
    return targetCode == ABS_Z || targetCode == ABS_RZ;
}

bool isHatAxis(int targetCode) {
    return targetCode == ABS_HAT0X || targetCode == ABS_HAT0Y;
}

int normalizeAxis(const struct input_absinfo &info, bool hasInfo, int targetCode, int value) {
    if (isHatAxis(targetCode)) {
        if (hasInfo && info.minimum <= -1 && info.maximum >= 1) {
            return std::clamp(value, -1, 1);
        }
        if (!hasInfo) return std::clamp(value, -1, 1);
        if (value <= info.minimum) return -1;
        if (value >= info.maximum) return 1;
        return 0;
    }

    if (!hasInfo) {
        return isTriggerAxis(targetCode) ? std::clamp(value, 0, 255)
                                         : std::clamp(value, -32768, 32767);
    }

    const int64_t range = static_cast<int64_t>(info.maximum) - info.minimum;
    const int64_t offset = static_cast<int64_t>(value) - info.minimum;
    if (isTriggerAxis(targetCode)) {
        return static_cast<int>(std::clamp<int64_t>((offset * 255 + range / 2) / range, 0, 255));
    }
    return static_cast<int>(std::clamp<int64_t>(-32768 + (offset * 65535 + range / 2) / range,
                                                -32768, 32767));
}

bool writeFully(int fd, const void *buffer, size_t size) {
    const auto *bytes = static_cast<const unsigned char *>(buffer);
    size_t offset = 0;
    while (offset < size) {
        ssize_t written = write(fd, bytes + offset, size - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) return false;
        offset += static_cast<size_t>(written);
    }
    return true;
}

bool emitEvent(int fd, uint16_t type, uint16_t code, int32_t value) {
    struct input_event ev{};
    gettimeofday(&ev.time, nullptr);
    ev.type = type;
    ev.code = code;
    ev.value = value;
    return writeFully(fd, &ev, sizeof(ev));
}

bool emitSync(int fd) {
    return emitEvent(fd, EV_SYN, SYN_REPORT, 0);
}

bool configureUinput(int fd, std::string &why) {
    auto set = [&](unsigned long request, int value, const char *label) -> bool {
        if (ioctl(fd, request, value) < 0) {
            why = std::string(label) + ": " + strerror(errno);
            return false;
        }
        return true;
    };

    if (!set(UI_SET_EVBIT, EV_SYN, "UI_SET_EVBIT EV_SYN") ||
        !set(UI_SET_EVBIT, EV_KEY, "UI_SET_EVBIT EV_KEY") ||
        !set(UI_SET_EVBIT, EV_ABS, "UI_SET_EVBIT EV_ABS")) return false;

    const int keyBits[] = {
        BTN_SOUTH, BTN_EAST, BTN_NORTH, BTN_WEST,
        BTN_TL, BTN_TR, BTN_TL2, BTN_TR2,
        BTN_SELECT, BTN_START, BTN_MODE, BTN_THUMBL, BTN_THUMBR,
        BTN_DPAD_UP, BTN_DPAD_DOWN, BTN_DPAD_LEFT, BTN_DPAD_RIGHT
    };
    for (int key : keyBits) {
        if (!set(UI_SET_KEYBIT, key, "UI_SET_KEYBIT")) return false;
    }
    for (int key = BTN_TRIGGER_HAPPY1; key <= BTN_TRIGGER_HAPPY40; ++key) {
        if (!set(UI_SET_KEYBIT, key, "UI_SET_KEYBIT trigger-happy")) return false;
    }

    const int absBits[] = {ABS_X, ABS_Y, ABS_RX, ABS_RY, ABS_Z, ABS_RZ, ABS_HAT0X, ABS_HAT0Y};
    for (int axis : absBits) {
        if (!set(UI_SET_ABSBIT, axis, "UI_SET_ABSBIT")) return false;
    }

    struct uinput_user_dev setup{};
    strncpy(setup.name, "Microsoft X-Box 360 pad", UINPUT_MAX_NAME_SIZE - 1);
    setup.id.bustype = BUS_USB;
    setup.id.vendor = 0x045e;
    setup.id.product = 0x028e;
    setup.id.version = 0x0114;

    auto setRange = [&](int axis, int minVal, int maxVal, int fuzz, int flat) {
        setup.absmin[axis] = minVal;
        setup.absmax[axis] = maxVal;
        setup.absfuzz[axis] = fuzz;
        setup.absflat[axis] = flat;
    };
    setRange(ABS_X, -32768, 32767, 16, 128);
    setRange(ABS_Y, -32768, 32767, 16, 128);
    setRange(ABS_RX, -32768, 32767, 16, 128);
    setRange(ABS_RY, -32768, 32767, 16, 128);
    setRange(ABS_Z, 0, 255, 0, 0);
    setRange(ABS_RZ, 0, 255, 0, 0);
    setRange(ABS_HAT0X, -1, 1, 0, 0);
    setRange(ABS_HAT0Y, -1, 1, 0, 0);

    if (!writeFully(fd, &setup, sizeof(setup))) {
        why = std::string("write uinput setup: ") + strerror(errno);
        return false;
    }
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
        why = std::string("UI_DEV_CREATE: ") + strerror(errno);
        return false;
    }
    return true;
}

void destroyReportDeviceLocked() {
    if (g_report_fd >= 0) {
        if (g_report_mode) ioctl(g_report_fd, UI_DEV_DESTROY);
        close(g_report_fd);
    }
    g_report_fd = -1;
    g_report_mode = false;
    g_report_has_data = false;
}

void releaseFds(std::vector<int> &inputFds, int outputFd, bool outputCreated) {
    if (outputFd >= 0 && outputCreated) ioctl(outputFd, UI_DEV_DESTROY);
    if (outputFd >= 0) close(outputFd);
    for (int fd : inputFds) {
        if (fd >= 0) {
            ioctl(fd, EVIOCGRAB, 0);
            close(fd);
        }
    }
    inputFds.clear();
}

} // namespace

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_runBridge(JNIEnv *env, jclass,
                                                         jobjectArray pathsArray,
                                                         jstring physicalName) {
    if (g_running.exchange(true)) {
        setStatus("ERROR: bridge is already running");
        return;
    }
    g_stop.store(false);

    const char *nameChars = physicalName ? env->GetStringUTFChars(physicalName, nullptr) : nullptr;
    std::string name = nameChars ? nameChars : "Physical gamepad";
    if (nameChars) env->ReleaseStringUTFChars(physicalName, nameChars);

    if (pathsArray == nullptr || env->GetArrayLength(pathsArray) == 0) {
        setStatus("ERROR: no input paths supplied");
        g_running.store(false);
        return;
    }

    std::vector<int> inputFds;
    std::vector<std::string> inputPaths;
    const jsize pathCount = env->GetArrayLength(pathsArray);
    inputFds.reserve(static_cast<size_t>(pathCount));
    inputPaths.reserve(static_cast<size_t>(pathCount));

    setStatus("Opening controller events for " + name + "...");
    for (jsize i = 0; i < pathCount; ++i) {
        jstring pathString = static_cast<jstring>(env->GetObjectArrayElement(pathsArray, i));
        const char *pathChars = env->GetStringUTFChars(pathString, nullptr);
        std::string path = pathChars ? pathChars : "";
        if (pathChars) env->ReleaseStringUTFChars(pathString, pathChars);
        env->DeleteLocalRef(pathString);

        if (path.rfind("/dev/input/event", 0) != 0) {
            setStatus("ERROR: rejected non-input path: " + path);
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
        int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) {
            setStatus("ERROR: cannot open " + path + ": " + strerror(errno) + ". Shizuku shell may not have permission on this tablet.");
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
        inputFds.push_back(fd);
        inputPaths.push_back(path);
    }

    for (size_t i = 0; i < inputFds.size(); ++i) {
        if (ioctl(inputFds[i], EVIOCGRAB, 1) < 0) {
            setStatus("ERROR: cannot exclusively grab " + inputPaths[i] + ": " + strerror(errno));
            releaseFds(inputFds, -1, false);
            g_running.store(false);
            return;
        }
    }

    // Cache physical axis ranges once, not once per frame; this reduces input-path overhead.
    std::vector<std::array<struct input_absinfo, ABS_CNT>> absInfos(inputFds.size());
    std::vector<std::array<bool, ABS_CNT>> absValid(inputFds.size());
    for (size_t i = 0; i < inputFds.size(); ++i) {
        absInfos[i].fill(input_absinfo{});
        absValid[i].fill(false);
        for (int code = 0; code <= ABS_MAX; ++code) {
            struct input_absinfo info{};
            if (ioctl(inputFds[i], EVIOCGABS(code), &info) == 0 && info.maximum > info.minimum) {
                absInfos[i][static_cast<size_t>(code)] = info;
                absValid[i][static_cast<size_t>(code)] = true;
            }
        }
    }

    int outputFd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (outputFd < 0) {
        setStatus(std::string("ERROR: cannot open /dev/uinput: ") + strerror(errno) +
                  ". If this is Permission denied, the tablet firmware blocks rootless virtual gamepads.");
        releaseFds(inputFds, -1, false);
        g_running.store(false);
        return;
    }

    std::string reason;
    if (!configureUinput(outputFd, reason)) {
        setStatus("ERROR: virtual Xbox creation failed: " + reason);
        releaseFds(inputFds, outputFd, false);
        g_running.store(false);
        return;
    }

    setStatus("RUNNING — virtual Xbox created; physical events grabbed. Test the Xbox device in a gamepad tester.");
    LOGI("Bridge started with %zu event node(s)", inputFds.size());

    std::vector<pollfd> pollFds(inputFds.size());
    for (size_t i = 0; i < inputFds.size(); ++i) {
        pollFds[i].fd = inputFds[i];
        pollFds[i].events = POLLIN;
        pollFds[i].revents = 0;
    }

    bool disconnected = false;
    bool failed = false;
    while (!g_stop.load()) {
        int ready = poll(pollFds.data(), static_cast<nfds_t>(pollFds.size()), 100);
        if (ready < 0) {
            if (errno == EINTR) continue;
            setStatus(std::string("ERROR: poll failed: ") + strerror(errno));
            failed = true;
            break;
        }
        if (ready == 0) continue;

        for (size_t i = 0; i < pollFds.size() && !g_stop.load(); ++i) {
            if (pollFds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                setStatus("Controller disconnected or input node closed: " + inputPaths[i]);
                disconnected = true;
                g_stop.store(true);
                break;
            }
            if (!(pollFds[i].revents & POLLIN)) continue;

            struct input_event events[32];
            ssize_t bytes = read(inputFds[i], events, sizeof(events));
            if (bytes < 0) {
                if (errno == EINTR || errno == EAGAIN) continue;
                setStatus(std::string("ERROR: input read failed: ") + strerror(errno));
                failed = true;
                g_stop.store(true);
                break;
            }
            if (bytes == 0) {
                setStatus("Controller input stream ended.");
                disconnected = true;
                g_stop.store(true);
                break;
            }
            const size_t count = static_cast<size_t>(bytes) / sizeof(struct input_event);
            for (size_t j = 0; j < count; ++j) {
                const struct input_event &ev = events[j];
                if (ev.type == EV_KEY) {
                    if (isPassThroughKey(ev.code)) {
                        if (!emitEvent(outputFd, EV_KEY, ev.code, ev.value)) {
                            setStatus(std::string("ERROR: virtual-key write failed: ") + strerror(errno));
                            failed = true;
                            g_stop.store(true);
                            break;
                        }
                    }
                } else if (ev.type == EV_ABS) {
                    int target = mapAbsCode(ev.code);
                    if (target >= 0) {
                        int mapped = normalizeAxis(absInfos[i][ev.code], absValid[i][ev.code], target, ev.value);
                        if (!emitEvent(outputFd, EV_ABS, static_cast<uint16_t>(target), mapped)) {
                            setStatus(std::string("ERROR: virtual-axis write failed: ") + strerror(errno));
                            failed = true;
                            g_stop.store(true);
                            break;
                        }
                    }
                } else if (ev.type == EV_SYN && ev.code == SYN_REPORT) {
                    if (!emitSync(outputFd)) {
                        setStatus(std::string("ERROR: virtual-sync write failed: ") + strerror(errno));
                        failed = true;
                        g_stop.store(true);
                        break;
                    }
                }
            }
            pollFds[i].revents = 0;
        }
    }

    releaseFds(inputFds, outputFd, true);
    if (g_stop.load() && !disconnected && !failed) setStatus("Stopped. Controller events have been released.");
    g_running.store(false);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_startXboxReportBridge(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_report_mutex);
    // Be resilient if the Android activity is recreated while Shizuku's daemon service
    // is still alive: reuse an already-created report device instead of failing blindly.
    if (g_report_mode && g_report_fd >= 0) {
        setStatus("RUNNING — reusing existing virtual Xbox device");
        return JNI_TRUE;
    }
    bool expected = false;
    if (!g_running.compare_exchange_strong(expected, true)) {
        setStatus("ERROR: another legacy bridge is already running");
        return JNI_FALSE;
    }

    g_stop.store(false);
    const int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) {
        g_running.store(false);
        setStatus(std::string("ERROR: cannot open /dev/uinput: ") + strerror(errno) +
                  ". The tablet firmware may block rootless virtual gamepads.");
        return JNI_FALSE;
    }

    std::string reason;
    if (!configureUinput(fd, reason)) {
        close(fd);
        g_running.store(false);
        setStatus("ERROR: virtual Xbox creation failed: " + reason);
        return JNI_FALSE;
    }

    g_report_fd = fd;
    g_report_mode = true;
    g_report_has_data = false;
    setStatus("RUNNING — virtual Xbox created; waiting for USB XInput reports");
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_sendXboxReport(JNIEnv *env, jclass, jbyteArray reportArray) {
    if (reportArray == nullptr) return;
    const jsize length = env->GetArrayLength(reportArray);
    if (length < 14 || length > 64) return;
    std::vector<jbyte> bytes(static_cast<size_t>(length));
    env->GetByteArrayRegion(reportArray, 0, length, bytes.data());
    if (env->ExceptionCheck()) { env->ExceptionClear(); return; }

    // The wired Vader 5 Pro's XInput interface reports packets beginning 00 14.
    if (static_cast<uint8_t>(bytes[0]) != 0x00 || static_cast<uint8_t>(bytes[1]) != 0x14) return;

    std::lock_guard<std::mutex> lock(g_report_mutex);
    if (!g_report_mode || g_report_fd < 0) return;
    const int fd = g_report_fd;
    const uint8_t b2 = static_cast<uint8_t>(bytes[2]);
    const uint8_t b3 = static_cast<uint8_t>(bytes[3]);
    const uint8_t lt = static_cast<uint8_t>(bytes[4]);
    const uint8_t rt = static_cast<uint8_t>(bytes[5]);
    auto i16le = [&](size_t offset) -> int {
        const uint16_t raw = static_cast<uint16_t>(static_cast<uint8_t>(bytes[offset])) |
                             (static_cast<uint16_t>(static_cast<uint8_t>(bytes[offset + 1])) << 8);
        return static_cast<int>(static_cast<int16_t>(raw));
    };

    struct KeyMap { int code; bool down; };
    const KeyMap keys[] = {
        {BTN_DPAD_UP,    (b2 & 0x01) != 0},
        {BTN_DPAD_DOWN,  (b2 & 0x02) != 0},
        {BTN_DPAD_LEFT,  (b2 & 0x04) != 0},
        {BTN_DPAD_RIGHT, (b2 & 0x08) != 0},
        {BTN_START,      (b2 & 0x10) != 0},
        {BTN_SELECT,     (b2 & 0x20) != 0},
        {BTN_THUMBL,     (b2 & 0x40) != 0},
        {BTN_THUMBR,     (b2 & 0x80) != 0},
        {BTN_TL,         (b3 & 0x01) != 0},
        {BTN_TR,         (b3 & 0x02) != 0},
        {BTN_MODE,       (b3 & 0x04) != 0},
        {BTN_SOUTH,      (b3 & 0x10) != 0},
        {BTN_EAST,       (b3 & 0x20) != 0},
        {BTN_WEST,       (b3 & 0x40) != 0},
        {BTN_NORTH,      (b3 & 0x80) != 0},
    };
    bool ok = true;
    for (const auto &key : keys) {
        if (!emitEvent(fd, EV_KEY, static_cast<uint16_t>(key.code), key.down ? 1 : 0)) { ok = false; break; }
    }
    const int hatX = ((b2 & 0x08) ? 1 : 0) - ((b2 & 0x04) ? 1 : 0);
    const int hatY = ((b2 & 0x02) ? 1 : 0) - ((b2 & 0x01) ? 1 : 0);
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_X, i16le(6));
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_Y, i16le(8));
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_RX, i16le(10));
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_RY, i16le(12));
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_Z, lt);
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_RZ, rt);
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_HAT0X, hatX);
    if (ok) ok = emitEvent(fd, EV_ABS, ABS_HAT0Y, hatY);
    if (ok) ok = emitSync(fd);
    if (!ok) {
        const std::string message = std::string("ERROR: writing XInput report to /dev/uinput failed: ") + strerror(errno);
        destroyReportDeviceLocked();
        g_running.store(false);
        setStatus(message);
        return;
    }
    if (!g_report_has_data) {
        g_report_has_data = true;
        setStatus("RUNNING — USB XInput reports received; virtual Xbox is receiving buttons and sticks");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_stopXboxReportBridge(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_report_mutex);
    if (g_report_mode) {
        destroyReportDeviceLocked();
        g_stop.store(false);
        g_running.store(false);
        setStatus("Stopped. Virtual Xbox removed and USB report bridge closed.");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_stopBridge(JNIEnv *, jclass) {
    {
        std::lock_guard<std::mutex> lock(g_report_mutex);
        if (g_report_mode) {
            destroyReportDeviceLocked();
            g_stop.store(false);
            g_running.store(false);
            setStatus("Stopped. Virtual Xbox removed and USB report bridge closed.");
            return;
        }
    }
    if (g_running.load()) {
        g_stop.store(true);
        setStatus("Stopping bridge…");
    } else {
        setStatus("Stopped");
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_vaderxboxbridge_NativeBridge_getBridgeStatus(JNIEnv *env, jclass) {
    const std::string status = getStatusCopy();
    return env->NewStringUTF(status.c_str());
}
