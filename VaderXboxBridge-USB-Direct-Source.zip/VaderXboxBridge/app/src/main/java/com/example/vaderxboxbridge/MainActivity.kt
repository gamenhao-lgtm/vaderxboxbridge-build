package com.example.vaderxboxbridge

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbRequest
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ViewGroup
import java.nio.ByteBuffer
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/** Experimental evdev -> uinput bridge. Not yet tested on the user's physical tablet/controller. */
class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var devicesSpinner: Spinner
    private lateinit var scanButton: Button
    private lateinit var connectButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var usbDirectButton: Button
    private val usbManager: UsbManager by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val usbPermissionAction: String get() = "$packageName.USB_PERMISSION"
    @Volatile private var usbReaderRunning = false
    @Volatile private var usbConnection: UsbDeviceConnection? = null
    @Volatile private var usbRequest: UsbRequest? = null
    @Volatile private var usbClaimedInterface: UsbInterface? = null
    @Volatile private var usbReaderThread: Thread? = null
    private var usbReceiverRegistered = false
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<DeviceEntry>()
    @Volatile private var remote: IBridgeService? = null
    @Volatile private var binding = false
    @Volatile private var monitorBridgeStatus = false

    private val userServiceArgs: Shizuku.UserServiceArgs
        get() = Shizuku.UserServiceArgs(
            ComponentName(packageName, BridgeUserService::class.java.name)
        ).daemon(true).processNameSuffix("vader_bridge").tag("vader-xbox-bridge").version(1)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IBridgeService.Stub.asInterface(service)
            binding = false
            setStatus("Shizuku connected. Scan for the physical controller.")
            setBusy(false)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            binding = false
            monitorBridgeStatus = false
            setStatus("Shizuku bridge disconnected. Check that Shizuku is still running.")
            setBusy(false)
        }
    }

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != usbPermissionAction) return
            val device = usbDeviceFromIntent(intent)
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                setStatus("USB permission granted. Opening interface 0 directly…")
                openUsbDirectBridge(device)
            } else {
                setStatus("Android USB permission was denied. The direct USB bridge cannot read the controller without it.")
            }
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { ensureShizukuPermissionAndBind() }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            remote = null
            binding = false
            setStatus("Shizuku stopped. Start it again, then reconnect here.")
            setBusy(false)
        }
    }
    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_SHIZUKU) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                bindUserService()
            } else {
                runOnUiThread { setStatus("Shizuku permission was denied.") }
            }
        }
    }

    private val statusPoll = object : Runnable {
        override fun run() {
            val svc = remote
            if (svc != null && monitorBridgeStatus) {
                io.execute {
                    try {
                        val value = svc.getBridgeStatus()
                        // Poll only while a bridge start/run is being observed. Old "Stopped"
                        // or "Idle" values must not overwrite the latest scan/connect result.
                        if (!value.isNullOrBlank() && value != "Idle" && value != "Stopped") {
                            runOnUiThread {
                                statusView.text = "Status: $value"
                                val stillActive = value.startsWith("RUNNING", true) ||
                                    value.startsWith("Starting", true) ||
                                    value.startsWith("Opening", true) ||
                                    value.startsWith("Stopping", true)
                                if (!stillActive) monitorBridgeStatus = false
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            statusView.text = "Status: service communication error — ${e.message}"
                            monitorBridgeStatus = false
                        }
                    }
                }
            }
            handler.postDelayed(this, 900L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val usbFilter = IntentFilter(usbPermissionAction)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, usbFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbPermissionReceiver, usbFilter)
        }
        usbReceiverRegistered = true
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        setStatus("Experimental prototype. Connect Vader 5 Pro by USB OTG, then connect Shizuku.")
        if (Shizuku.pingBinder()) ensureShizukuPermissionAndBind()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(statusPoll)
        handler.post(statusPoll)
    }

    override fun onPause() {
        handler.removeCallbacks(statusPoll)
        super.onPause()
    }

    override fun onDestroy() {
        stopUsbReaderLocal()
        try { remote?.stopUsbDirectBridge() } catch (_: Exception) { }
        if (usbReceiverRegistered) {
            try { unregisterReceiver(usbPermissionReceiver) } catch (_: Exception) { }
            usbReceiverRegistered = false
        }
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        if (binding) {
            try { Shizuku.unbindUserService(userServiceArgs, serviceConnection, false) } catch (_: Exception) { }
        } else {
            try { Shizuku.unbindUserService(userServiceArgs, serviceConnection, false) } catch (_: Exception) { }
        }
        io.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val outer = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }
        outer.addView(root)

        val title = TextView(this).apply {
            text = "Vader Xbox Bridge"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Prototype: physical USB controller → system-wide virtual Xbox 360 controller"
            textSize = 14f
        }
        root.addView(subtitle, lp(top = 4))

        val warning = TextView(this).apply {
            text = "Experimental source build, not a verified release. The new USB-direct path reads the Vader 5 Pro Xbox-like USB interface instead of treating event13's mouse interface as a gamepad. It still needs a real-device build/test."
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFFFFF1CC.toInt())
        }
        root.addView(warning, lp(top = 14))

        connectButton = Button(this).apply {
            text = "1. Connect Shizuku"
            setOnClickListener { ensureShizukuPermissionAndBind() }
        }
        root.addView(connectButton, lp(top = 14))

        scanButton = Button(this).apply {
            text = "2. Scan physical gamepads"
            setOnClickListener { scanDevices() }
        }
        root.addView(scanButton, lp(top = 6))

        devicesSpinner = Spinner(this)
        root.addView(devicesSpinner, lp(top = 6))

        startButton = Button(this).apply {
            text = "3. Start event-node bridge (legacy)"
            setOnClickListener { startBridge() }
        }
        root.addView(startButton, lp(top = 6))

        usbDirectButton = Button(this).apply {
            text = "4. Start USB-direct Vader bridge"
            setOnClickListener { startUsbDirectBridgeClicked() }
        }
        root.addView(usbDirectButton, lp(top = 6))

        stopButton = Button(this).apply {
            text = "Stop bridge"
            setOnClickListener { stopBridge() }
        }
        root.addView(stopButton, lp(top = 6))

        statusView = TextView(this).apply {
            text = "Status: Idle"
            textSize = 14f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEFEFEF.toInt())
        }
        root.addView(statusView, lp(top = 14))

        val note = TextView(this).apply {
            text = "USB-direct mode asks Android for permission to read the Flydigi USB device (VID 37D7 / PID 2401), reads interface 0's interrupt-IN reports, and forwards button/axis state to a virtual Xbox device created by Shizuku. The legacy event-node mode remains available for ordinary gamepads. Gyro, M1–M4 mapping, and rumble are not included in this USB-direct test."
            textSize = 13f
        }
        root.addView(note, lp(top = 12))
        setContentView(outer)
        setBusy(false)
    }

    private fun ensureShizukuPermissionAndBind() {
        if (remote != null) {
            setStatus("Shizuku connected. You can scan for the physical controller.")
            return
        }
        if (binding) {
            setStatus("Connecting to Shizuku…")
            return
        }
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku is not running. Open Shizuku and start it with Wireless debugging, then return here.")
            setBusy(false)
            return
        }
        try {
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setStatus("Waiting for Shizuku permission…")
                Shizuku.requestPermission(REQUEST_SHIZUKU)
            } else {
                bindUserService()
            }
        } catch (e: Exception) {
            setStatus("Shizuku check failed: ${e.message}")
        }
    }

    private fun bindUserService() {
        if (remote != null || binding) return
        binding = true
        setBusy(true)
        setStatus("Binding shell-UID bridge service…")
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Exception) {
            binding = false
            setBusy(false)
            setStatus("Could not start Shizuku service: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceFromIntent(intent: Intent): UsbDevice? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
        }
    }

    private fun startUsbDirectBridgeClicked() {
        if (usbReaderRunning) {
            setStatus("USB-direct reader is already running. Use Stop bridge before restarting it.")
            return
        }
        if (remote == null) {
            setStatus("Connect Shizuku first. When the status says connected, tap USB-direct again.")
            ensureShizukuPermissionAndBind()
            return
        }
        val device = usbManager.deviceList.values.firstOrNull {
            it.vendorId == FLYDIGI_VID && it.productId == VADER5_PID
        }
        if (device == null) {
            setStatus("UsbManager did not list VID 37D7 / PID 2401. Android's dumpsys showed it, but this app needs the Android USB permission/device handle.")
            return
        }
        if (!usbManager.hasPermission(device)) {
            val intent = Intent(usbPermissionAction).setPackage(packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            val permissionIntent = PendingIntent.getBroadcast(this, USB_PERMISSION_REQUEST, intent, flags)
            setStatus("Requesting Android USB permission for ${device.productName ?: "Flydigi Vader 5 Pro"}… approve the system dialog.")
            usbManager.requestPermission(device, permissionIntent)
            return
        }
        openUsbDirectBridge(device)
    }

    private fun openUsbDirectBridge(device: UsbDevice) {
        if (usbReaderRunning) return
        val svc = remote
        if (svc == null) {
            setStatus("Shizuku service is not connected yet. Tap USB-direct after it reconnects.")
            return
        }
        val iface = (0 until device.interfaceCount).map { device.getInterface(it) }
            .firstOrNull { it.id == 0 && it.interfaceClass == USB_CLASS_VENDOR && it.interfaceSubclass == USB_SUBCLASS_XBOX }
            ?: (0 until device.interfaceCount).map { device.getInterface(it) }.firstOrNull { it.id == 0 }
        if (iface == null) {
            setStatus("USB device found, but interface 0 could not be selected.")
            return
        }
        val endpoint = (0 until iface.endpointCount).map { iface.getEndpoint(it) }
            .firstOrNull { it.address == USB_EP_IN || (it.direction == UsbConstants.USB_DIR_IN && it.type == UsbConstants.USB_ENDPOINT_XFER_INT) }
        if (endpoint == null) {
            setStatus("Interface 0 was found, but its interrupt-IN endpoint was not available.")
            return
        }
        val connection = try { usbManager.openDevice(device) } catch (e: Exception) { null }
        if (connection == null) {
            setStatus("Android could not open the USB device. Recheck the system USB permission and OTG connection.")
            return
        }
        if (!connection.claimInterface(iface, true)) {
            connection.close()
            setStatus("Could not claim USB interface 0. Android/the kernel may still own this interface.")
            return
        }
        val started = try { svc.startUsbDirectBridge() } catch (e: Exception) {
            connection.releaseInterface(iface)
            connection.close()
            setStatus("Could not create virtual Xbox through Shizuku: ${e.message}")
            return
        }
        if (!started) {
            val why = try { svc.getBridgeStatus() } catch (_: Exception) { "Shizuku service returned no status" }
            connection.releaseInterface(iface)
            connection.close()
            setStatus(why)
            return
        }
        val request = UsbRequest()
        if (!request.initialize(connection, endpoint)) {
            try { svc.stopUsbDirectBridge() } catch (_: Exception) { }
            connection.releaseInterface(iface)
            connection.close()
            setStatus("Could not initialize a USB read request on endpoint 0x${endpoint.address.toString(16)}.")
            return
        }
        usbConnection = connection
        usbClaimedInterface = iface
        usbRequest = request
        usbReaderRunning = true
        monitorBridgeStatus = true
        setStatus("USB direct opened: VID 37D7 / PID 2401, interface ${iface.id}, endpoint 0x${endpoint.address.toString(16)}. Waiting for controller reports…")
        setBusy(false)
        val reader = Thread({ readUsbReports(connection, iface, endpoint, request, svc) }, "VaderUSBReader")
        usbReaderThread = reader
        reader.start()
    }

    private fun readUsbReports(
        connection: UsbDeviceConnection,
        iface: UsbInterface,
        endpoint: UsbEndpoint,
        request: UsbRequest,
        svc: IBridgeService
    ) {
        var validReports = 0
        var rawReports = 0
        var failure: String? = null
        val buffer = ByteBuffer.allocateDirect(endpoint.maxPacketSize.coerceAtLeast(32))
        try {
            while (usbReaderRunning) {
                buffer.clear()
                if (!request.queue(buffer, buffer.capacity())) {
                    if (usbReaderRunning) failure = "USB request queue failed"
                    break
                }
                val completed = connection.requestWait(1000L) ?: continue
                if (completed !== request) continue
                val actualPosition = buffer.position()
                val amount = (if (actualPosition > 0) actualPosition else buffer.limit())
                    .coerceAtMost(buffer.capacity())
                if (amount <= 0) continue
                buffer.position(0)
                buffer.limit(amount)
                val report = ByteArray(amount)
                buffer.get(report)
                rawReports++
                val accepted = try { svc.sendUsbReport(report) } catch (e: Exception) {
                    failure = "Shizuku report forwarding failed: ${e.message}"
                    break
                }
                if (accepted) {
                    validReports++
                    if (validReports == 1 || validReports % 50 == 0) {
                        val count = validReports
                        handler.post { if (usbReaderRunning) setStatus("RUNNING — direct USB reports decoded: $count; virtual Xbox is active.") }
                    }
                }
            }
        } catch (e: Exception) {
            if (usbReaderRunning) failure = "USB read stopped: ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            usbReaderRunning = false
            try { request.cancel() } catch (_: Exception) { }
            try { request.close() } catch (_: Exception) { }
            try { connection.releaseInterface(iface) } catch (_: Exception) { }
            try { connection.close() } catch (_: Exception) { }
            if (usbRequest === request) usbRequest = null
            if (usbConnection === connection) usbConnection = null
            if (usbClaimedInterface === iface) usbClaimedInterface = null
            usbReaderThread = null
            try { svc.stopUsbDirectBridge() } catch (_: Exception) { }
            val finalRaw = rawReports
            val finalValid = validReports
            val finalFailure = failure
            handler.post {
                monitorBridgeStatus = false
                if (finalFailure != null) setStatus("$finalFailure (raw reports: $finalRaw, decoded: $finalValid)")
                else if (finalValid == 0 && finalRaw == 0) setStatus("USB interface opened, but endpoint 0x${endpoint.address.toString(16)} delivered no reports. No event13 retry needed; next implementation step is the extended FFA0 interface.")
                else if (finalValid == 0) setStatus("USB packets arrived ($finalRaw) but did not match the expected XInput report. Next step is decode/interface fallback.")
                else setStatus("USB-direct bridge stopped. Decoded reports: $finalValid.")
                setBusy(false)
            }
        }
    }

    private fun stopUsbReaderLocal() {
        usbReaderRunning = false
        try { usbRequest?.cancel() } catch (_: Exception) { }
        try { usbRequest?.close() } catch (_: Exception) { }
        try { usbConnection?.close() } catch (_: Exception) { }
        usbRequest = null
        usbConnection = null
        usbClaimedInterface = null
    }

    private fun scanDevices() {
        val svc = remote
        if (svc == null) {
            ensureShizukuPermissionAndBind()
            return
        }
        setBusy(true)
        setStatus("Scanning /dev/input/event* via getevent…")
        io.execute {
            try {
                val result = svc.listDevices() ?: emptyArray()
                runOnUiThread {
                    entries.clear()
                    val error = result.firstOrNull { it.startsWith("__ERROR__\t") }
                    val diagnostic = result.firstOrNull { it.startsWith("__INFO__\t") }
                    if (error != null) {
                        setStatus(error.substringAfter('\t'))
                        setDevices(emptyList())
                    } else if (diagnostic != null) {
                        setStatus(diagnostic.substringAfter('\t'))
                        setDevices(emptyList())
                    } else {
                        for (item in result) {
                            val parts = item.split('\t', limit = 2)
                            if (parts.size == 2) {
                                val paths = parts[1].split(';').filter { it.startsWith("/dev/input/event") }
                                if (paths.isNotEmpty()) entries.add(DeviceEntry(parts[0], paths))
                            }
                        }
                        setDevices(entries)
                        if (entries.isEmpty()) {
                            setStatus("No gamepad-like event node found. Check USB OTG/controller mode, then scan again.")
                        } else {
                            val flydigiIndex = entries.indexOfFirst { it.name.contains("flydigi", true) || it.name.contains("vader", true) }
                            if (flydigiIndex >= 0) devicesSpinner.setSelection(flydigiIndex)
                            setStatus("Found ${entries.size} gamepad candidate(s). Select Flydigi Vader 5 Pro if listed.")
                        }
                    }
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("Scan failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun startBridge() {
        val svc = remote
        if (svc == null) {
            ensureShizukuPermissionAndBind()
            return
        }
        val entry = entries.getOrNull(devicesSpinner.selectedItemPosition)
        if (entry == null) {
            setStatus("Scan and select the Flydigi controller first.")
            return
        }
        setBusy(true)
        // Start polling only after the service accepts this request, avoiding stale status from an older run.
        monitorBridgeStatus = false
        setStatus("Starting bridge for ${entry.name}…")
        io.execute {
            try {
                val started = svc.startBridge(entry.paths.toTypedArray(), entry.name)
                runOnUiThread {
                    monitorBridgeStatus = started
                    setStatus(if (started) "Start requested. Watch the status below for RUNNING or an explicit error." else svc.getBridgeStatus())
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    monitorBridgeStatus = false
                    setStatus("Start failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun stopBridge() {
        monitorBridgeStatus = false
        stopUsbReaderLocal()
        val svc = remote
        if (svc == null) {
            setStatus("USB reader stopped locally. Shizuku service is not connected to destroy a virtual device.")
            setBusy(false)
            return
        }
        setBusy(true)
        io.execute {
            try {
                svc.stopUsbDirectBridge()
                svc.stopBridge()
                val text = svc.getBridgeStatus()
                runOnUiThread {
                    setStatus(text)
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setStatus("Stop failed: ${e.message}")
                    setBusy(false)
                }
            }
        }
    }

    private fun setDevices(list: List<DeviceEntry>) {
        val labels = if (list.isEmpty()) listOf("No gamepad detected") else list.map {
            "${it.name}  •  ${it.paths.joinToString()}"
        }
        devicesSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun setStatus(text: String) {
        if (::statusView.isInitialized) statusView.text = "Status: $text"
    }

    private fun setBusy(busy: Boolean) {
        if (::scanButton.isInitialized) {
            scanButton.isEnabled = !busy
            connectButton.isEnabled = !busy
            startButton.isEnabled = !busy
            usbDirectButton.isEnabled = !busy
            stopButton.isEnabled = !busy
        }
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { if (top > 0) topMargin = dp(top) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private data class DeviceEntry(val name: String, val paths: List<String>)

    companion object {
        private const val REQUEST_SHIZUKU = 2407
        private const val USB_PERMISSION_REQUEST = 2408
        private const val FLYDIGI_VID = 0x37D7
        private const val VADER5_PID = 0x2401
        private const val USB_CLASS_VENDOR = 0xFF
        private const val USB_SUBCLASS_XBOX = 0x5D
        private const val USB_EP_IN = 0x81
    }
}
