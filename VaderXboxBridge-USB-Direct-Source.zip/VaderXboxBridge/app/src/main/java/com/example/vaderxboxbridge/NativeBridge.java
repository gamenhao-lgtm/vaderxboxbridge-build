package com.example.vaderxboxbridge;

/** Native input reader and Linux uinput writer, loaded inside Shizuku's shell-UID UserService. */
public final class NativeBridge {
    static {
        System.loadLibrary("vaderbridge");
    }

    private NativeBridge() { }

    /** Legacy evdev-to-uinput bridge. */
    public static native void runBridge(String[] eventPaths, String physicalName);

    /** Creates a virtual Xbox gamepad which accepts standard 20-byte Xbox 360 reports. */
    public static native boolean startXboxReportBridge();

    /** Forwards one USB XInput report to the virtual gamepad. */
    public static native void sendXboxReport(byte[] report);

    public static native void stopXboxReportBridge();
    public static native void stopBridge();
    public static native String getBridgeStatus();
}
