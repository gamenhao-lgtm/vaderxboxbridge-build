package com.example.vaderxboxbridge;

/** Native evdev reader and shell-UID uinput writer used by the Shizuku UserService. */
public final class NativeBridge {
    static {
        System.loadLibrary("vaderbridge");
    }

    private NativeBridge() { }

    /** Blocks until stop is requested or an input/output error occurs. */
    public static native void runBridge(String[] eventPaths, String physicalName);
    public static native void stopBridge();
    public static native String getBridgeStatus();

    /** Creates a virtual Xbox device for packets read by Android UsbManager. */
    public static native boolean startUsbReportBridge();
    /** Decodes one USB input report and sends its state to the virtual Xbox device. */
    public static native boolean pushUsbReport(byte[] report);
    /** Destroys the USB-report virtual Xbox device. */
    public static native void stopUsbReportBridge();
}
