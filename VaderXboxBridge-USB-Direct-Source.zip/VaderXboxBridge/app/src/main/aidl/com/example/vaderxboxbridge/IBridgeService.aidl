package com.example.vaderxboxbridge;

interface IBridgeService {
    String[] listDevices();
    boolean startBridge(in String[] paths, String name);
    boolean startUsbDirectBridge();
    boolean sendUsbReport(in byte[] report);
    void stopUsbDirectBridge();
    void stopBridge();
    String getBridgeStatus();
}
