package com.example.vaderxboxbridge;

interface IBridgeService {
    String[] listDevices();
    boolean startBridge(in String[] paths, String name);
    boolean startXboxReportBridge();
    void sendXboxReport(in byte[] report);
    void stopXboxReportBridge();
    void stopBridge();
    String getBridgeStatus();
}
